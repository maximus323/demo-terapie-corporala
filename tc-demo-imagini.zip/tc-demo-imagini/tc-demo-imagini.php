<?php
/**
 * Plugin Name: Terapie Corporală — imagini pentru demo
 * Description: DOAR PENTRU SITE-UL DEMO. Fotografiile sunt găzduite pe terapiecorporala.ro, care blochează afișarea lor pe alte domenii; acest plugin le permite să apară în demo. Nu instalați pe site-ul real.
 * Version: 1.0.0
 * Requires at least: 6.6
 * License: Proprietary
 */

defined( 'ABSPATH' ) || exit;

function tc_demo_no_referrer() {
	echo '<meta name="referrer" content="no-referrer">' . "\n";
}
add_action( 'wp_head', 'tc_demo_no_referrer', 0 );
add_action( 'admin_head', 'tc_demo_no_referrer', 0 );
