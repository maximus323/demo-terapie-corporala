<?php
/**
 * Plugin Name: Terapie Corporală — imagini pentru demo
 * Description: DOAR PENTRU SITE-UL DEMO. Fotografiile sunt găzduite pe terapiecorporala.ro, care blochează afișarea lor pe alte domenii; acest plugin le permite să apară în demo. Nu instalați pe site-ul real.
 * Version: 1.1.0
 * Requires at least: 6.6
 * License: Proprietary
 */

defined( 'ABSPATH' ) || exit;

/* The live site only shows its photos when no referrer is sent. */
function tc_demo_no_referrer() {
	echo '<meta name="referrer" content="no-referrer">' . "\n";
}
add_action( 'wp_head', 'tc_demo_no_referrer', 0 );
add_action( 'admin_head', 'tc_demo_no_referrer', 0 );

/* Imported pages point to this demo's /wp-content/uploads, where the photos do not exist: load them from the live site. */
function tc_demo_live_images( $html ) {
	return str_replace( home_url( '/wp-content/uploads/' ), 'https://www.terapiecorporala.ro/wp-content/uploads/', $html );
}
add_filter( 'the_content', 'tc_demo_live_images', 99 );
