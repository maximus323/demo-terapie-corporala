<?php
/**
 * Terapie Corporală — block theme bootstrap.
 * Pages, templates, header and footer are edited in Appearance → Editor;
 * colours and fonts in Appearance → Editor → Styles.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

define( 'TC_VERSION', '3.0.0' );
define( 'TC_DIR', get_template_directory() );
define( 'TC_URI', get_template_directory_uri() );

require_once TC_DIR . '/inc/settings.php';
require_once TC_DIR . '/inc/icons.php';
require_once TC_DIR . '/inc/content.php';
require_once TC_DIR . '/inc/booking.php';
require_once TC_DIR . '/inc/blocks.php';

add_action( 'after_setup_theme', 'tc_setup' );
function tc_setup() {
	load_theme_textdomain( 'tc', TC_DIR . '/languages' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	remove_theme_support( 'core-block-patterns' );
}

/* Fonts + theme CSS on the site and inside the editor. */
add_action( 'enqueue_block_assets', 'tc_block_assets' );
function tc_block_assets() {
	// TODO before launch: self-host these fonts (GDPR) and drop the Google request.
	wp_enqueue_style(
		'tc-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'tc-main', get_stylesheet_uri(), array( 'tc-fonts' ), TC_VERSION );
}

add_action( 'wp_enqueue_scripts', 'tc_front_script' );
function tc_front_script() {
	wp_enqueue_script(
		'tc-main',
		TC_URI . '/assets/main.js',
		array(),
		TC_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}

/* Lets CSS hide reveal-on-scroll elements only when JS runs (no-JS shows everything). */
add_action( 'wp_head', 'tc_js_flag', 1 );
function tc_js_flag() {
	echo "<script>document.documentElement.classList.add('js')</script>\n";
}

/* Button styles the client can pick in the editor (default = gold). */
add_action( 'init', 'tc_block_styles' );
function tc_block_styles() {
	register_block_style( 'core/button', array( 'name' => 'linie', 'label' => __( 'Contur', 'tc' ) ) );
	register_block_style( 'core/button', array( 'name' => 'inchis', 'label' => __( 'Închis', 'tc' ) ) );
	register_block_style( 'core/group', array( 'name' => 'banda-inchisa', 'label' => __( 'Bandă închisă', 'tc' ) ) );
	register_block_pattern_category( 'terapie-corporala', array( 'label' => 'Terapie Corporală' ) );
}

/* Floating WhatsApp + mobile call bar on every page. */
add_action( 'wp_footer', 'tc_floating_actions' );
function tc_floating_actions() {
	$wa = tc_wa_href();
	if ( $wa ) {
		printf(
			'<a class="wa-float" href="%1$s" target="_blank" rel="noopener" aria-label="%2$s">%3$s</a>',
			esc_url( $wa ),
			esc_attr__( 'Scrieți-ne pe WhatsApp', 'tc' ),
			tc_icon( 'wa' ) // phpcs:ignore WordPress.Security.EscapeOutput
		);
	}
	printf(
		'<nav class="mbar" aria-label="%1$s"><a href="%2$s">%3$s%4$s</a><a href="%5$s">%6$s</a></nav>',
		esc_attr__( 'Contact rapid', 'tc' ),
		esc_attr( tc_tel_href() ),
		tc_icon( 'phone' ), // phpcs:ignore WordPress.Security.EscapeOutput
		esc_html__( 'Sună', 'tc' ),
		esc_url( home_url( '/#programare' ) ),
		esc_html__( 'Programează-te', 'tc' )
	);
}

function tc_tel_href() {
	$digits = preg_replace( '/[^0-9+]/', '', tc_opt( 'telefon' ) );
	if ( 0 === strpos( $digits, '0' ) ) {
		$digits = '+4' . $digits;
	}
	return 'tel:' . $digits;
}

function tc_wa_href() {
	$digits = preg_replace( '/[^0-9]/', '', tc_opt( 'whatsapp' ) );
	return $digits ? 'https://wa.me/' . $digits : '';
}

function tc_stars( $count = 5 ) {
	$count = max( 1, min( 5, (int) $count ) );
	$out   = '<span class="stars" role="img" aria-label="' . esc_attr( sprintf( __( '%d din 5 stele', 'tc' ), $count ) ) . '">';
	$out  .= str_repeat( tc_icon( 'star' ), $count );
	return $out . '</span>';
}
