<?php
/**
 * Terapie Corporală — block theme with the same structure as the old site
 * (Twenty Sixteen): title + header photo, page content, sidebar with the
 * page list. No menu bar. Pages, header, sidebar and footer are edited in
 * Appearance → Editor; widgets in Appearance → Widgets.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

define( 'TC_VERSION', '4.4.5' );
define( 'TC_DIR', get_template_directory() );
define( 'TC_URI', get_template_directory_uri() );

require_once TC_DIR . '/inc/settings.php';
require_once TC_DIR . '/inc/icons.php';
require_once TC_DIR . '/inc/blocks.php';

add_action( 'after_setup_theme', 'tc_setup' );
function tc_setup() {
	load_theme_textdomain( 'tc', TC_DIR . '/languages' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
}

/* Theme CSS on the site and inside the editor. Fonts are self-hosted via theme.json. */
add_action( 'enqueue_block_assets', 'tc_block_assets' );
function tc_block_assets() {
	wp_enqueue_style( 'tc-main', get_stylesheet_uri(), array(), TC_VERSION );
	// Text of the "Apasă aici" label on the treatment buttons (Setări → Date cabinet).
	$apasa = str_replace( array( '\\', '"', "\n", '<' ), array( '\\\\', '\\"', ' ', '' ), (string) tc_opt( 'text_apasa' ) );
	wp_add_inline_style( 'tc-main', ':root{--tc-apasa:"' . $apasa . '"}' );
}

/*
 * Widget areas with the same IDs as Twenty Sixteen, so the client's existing
 * widgets (page list, map, reviews, counters) move over untouched when the
 * theme is switched.
 */
add_action( 'widgets_init', 'tc_widget_areas' );
function tc_widget_areas() {
	$areas = array(
		'sidebar-1' => array( 'Bară laterală', 'Apare lângă conținut pe calculator și sub conținut pe telefon.' ),
		'sidebar-2' => array( 'Sub conținut 1', 'Apare sub conținutul fiecărei pagini.' ),
		'sidebar-3' => array( 'Sub conținut 2', 'Apare sub „Sub conținut 1”.' ),
	);
	foreach ( $areas as $id => $area ) {
		register_sidebar(
			array(
				'id'            => $id,
				'name'          => $area[0],
				'description'   => $area[1],
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
}

/* Block styles the client can pick in the editor. */
add_action( 'init', 'tc_block_styles' );
function tc_block_styles() {
	register_block_style( 'core/button', array( 'name' => 'auriu', 'label' => __( 'Auriu', 'tc' ) ) );
	register_block_style( 'core/button', array( 'name' => 'contur', 'label' => __( 'Contur', 'tc' ) ) );
	register_block_style( 'core/group', array( 'name' => 'caseta', 'label' => __( 'Casetă albă', 'tc' ) ) );
}

/*
 * Floating "Sună acum" + WhatsApp buttons, same place as the old plugins
 * (call bottom-left, WhatsApp bottom-right). Both switches are in
 * Setări → Date cabinet → Opțiuni.
 */
function tc_show_floating_buttons() {
	return (bool) apply_filters( 'tc_floating_buttons', tc_opt_on( 'opt_butoane' ) );
}

add_filter( 'body_class', 'tc_body_class' );
function tc_body_class( $classes ) {
	if ( tc_show_floating_buttons() ) {
		$classes[] = 'tc-fab-on';
	}
	if ( tc_opt_on( 'opt_ascunde_pluginuri' ) ) {
		$classes[] = 'tc-hide-plugin-fab';
	}
	if ( tc_show_floating_buttons() && tc_review_links() ) {
		$classes[] = 'tc-reviews-on';
	}
	return $classes;
}

/*
 * Small "Vezi recenzii pe Google / Facebook" buttons shown above "Sună acum".
 * Links, texts and the on/off switch: Setări → Date cabinet → Recenzii.
 */
function tc_review_links() {
	if ( ! tc_opt_on( 'opt_recenzii' ) ) {
		return array();
	}
	$links = array();
	foreach ( array( 'google', 'facebook' ) as $site ) {
		$url = tc_opt( 'recenzii_' . $site );
		if ( $url ) {
			$links[ $site ] = array( $url, tc_opt( 'text_recenzii_' . $site ) );
		}
	}
	return $links;
}

function tc_review_logo( $site ) {
	if ( 'google' === $site ) {
		return '<svg class="rev-logo" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 0 1-2.4 3.6v3h3.9c2.3-2.1 3.5-5.2 3.5-8.8z"/><path fill="#34A853" d="M12 24c3.2 0 6-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2-3.1 0-5.7-2.1-6.6-4.9H1.4v3.1A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.4 14.4a7.2 7.2 0 0 1 0-4.7V6.6h-4a12 12 0 0 0 0 10.9l4-3.1z"/><path fill="#EA4335" d="M12 4.8c1.7 0 3.3.6 4.5 1.8l3.4-3.4A12 12 0 0 0 1.4 6.6l4 3.1C6.3 6.9 8.9 4.8 12 4.8z"/></svg>';
	}
	return '<svg class="rev-logo" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#1877F2"/><path fill="#fff" d="M13.4 19.5v-6.2h2.1l.3-2.5h-2.4V9.3c0-.7.2-1.2 1.2-1.2h1.3V5.9c-.2 0-1-.1-1.9-.1-1.9 0-3.2 1.2-3.2 3.3v1.8H8.7v2.5h2.1v6.2h2.6z"/></svg>';
}

add_action( 'wp_footer', 'tc_floating_actions' );
function tc_floating_actions() {
	if ( ! tc_show_floating_buttons() ) {
		return;
	}
	echo '<div class="fab-left">';
	foreach ( tc_review_links() as $site => $link ) {
		printf(
			'<a class="fab-review fab-review-%1$s" href="%2$s" target="_blank" rel="noopener">%3$s<span class="rev-text">%4$s</span><span class="rev-star" aria-hidden="true">★</span><span class="rev-mini" aria-hidden="true">%5$s</span></a>',
			esc_attr( $site ),
			esc_url( $link[0] ),
			tc_review_logo( $site ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( $link[1] ),
			esc_html( tc_opt( 'text_recenzii_scurt' ) )
		);
	}
	printf(
		'<a class="fab fab-call" href="%1$s">%2$s<span>%3$s</span></a>',
		esc_attr( tc_tel_href() ),
		tc_icon( 'phone' ), // phpcs:ignore WordPress.Security.EscapeOutput
		esc_html( tc_opt( 'text_suna' ) )
	);
	echo '</div>';
	$wa = tc_wa_href();
	if ( $wa ) {
		printf(
			'<a class="fab fab-wa" href="%1$s" target="_blank" rel="noopener">%2$s<span>%3$s</span></a>',
			esc_url( $wa ),
			tc_icon( 'wa' ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( tc_opt( 'text_whatsapp' ) )
		);
	}
}

function tc_tel_href() {
	$digits = preg_replace( '/[^0-9+]/', '', tc_opt( 'telefon' ) );
	if ( 0 === strpos( $digits, '0' ) ) {
		$digits = '+4' . $digits;
	}
	return 'tel:' . $digits;
}

function tc_wa_href() {
	$digits = preg_replace( '/[^0-9]/', '', tc_opt( 'whatsapp' ) );
	return $digits ? 'https://wa.me/' . $digits : '';
}

/*
 * Lines in the page text that start with the 👉 emoji (e.g. "👉 durere de spate"
 * on the front page) become "call us" links, so a patient can tap the
 * complaint and phone the clinic. Matches the emoji as a character or as the
 * Facebook emoji image (…/1f449.png) the old pages use. Switch: Setări →
 * Date cabinet → Opțiuni.
 */
add_filter( 'the_content', 'tc_emoji_tel_links', 20 );
function tc_emoji_tel_links( $html ) {
	if ( ! apply_filters( 'tc_emoji_tel_links', tc_opt_on( 'opt_emoji' ) ) || ( false === strpos( $html, '1f449' ) && false === strpos( $html, "\u{1F449}" ) ) ) {
		return $html;
	}
	$pattern = '#<(div|p)([^>]*)>\s*((?:<span[^>]*>)?\s*(?:<img[^>]*1f449[^>]*>|\x{1F449})\s*(?:</span>)?)\s*([^<]+?)\s*</\1>#u';
	$tel     = esc_attr( tc_tel_href() );
	$label   = esc_attr( tc_opt( 'text_suna' ) );
	$result  = preg_replace(
		$pattern,
		'<$1$2><a class="tel-line" href="' . $tel . '" aria-label="$4 – ' . $label . '">$3 $4</a></$1>',
		$html
	);
	return null === $result ? $html : $result;
}

/*
 * Old links with a misplaced hyphen (e.g. /rtms-stimularea-.../ for the page
 * /rtmsstimularea-.../) give "page not found". When exactly one published page
 * has the same address once hyphens are ignored, send the visitor there (301).
 */
add_action( 'template_redirect', 'tc_redirect_hyphen_typos' );
function tc_redirect_hyphen_typos() {
	if ( ! is_404() || ! tc_opt_on( 'opt_redirect' ) ) {
		return;
	}
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$slug = sanitize_title( basename( $path ) );
	if ( '' === $slug || strlen( $slug ) < 6 ) {
		return;
	}
	$key     = str_replace( '-', '', $slug );
	$matches = array();
	foreach ( get_pages( array( 'post_status' => 'publish' ) ) as $page ) {
		if ( str_replace( '-', '', $page->post_name ) === $key ) {
			$matches[] = $page->ID;
		}
	}
	if ( 1 === count( $matches ) ) {
		wp_safe_redirect( get_permalink( $matches[0] ), 301 );
		exit;
	}
}

/*
 * Images that ship with the theme (e.g. the header photo) are written in the
 * templates as "/wp-content/themes/terapie-corporala/...". That only works when
 * WordPress sits at the root of the domain, so turn it into the theme's real
 * address (works in a sub-folder, on staging and in the Playground demo).
 */
add_filter( 'render_block_core/image', 'tc_theme_image_urls' );
function tc_theme_image_urls( $html ) {
	$relative = '/wp-content/themes/' . get_template() . '/';
	if ( false === strpos( $html, $relative ) ) {
		return $html;
	}
	return str_replace(
		array( 'src="' . $relative, "src='" . $relative ),
		array( 'src="' . trailingslashit( get_template_directory_uri() ), "src='" . trailingslashit( get_template_directory_uri() ) ),
		$html
	);
}

/*
 * Version 3 of this theme replaced the front page with an "Acasă" page.
 * If that happened on this site, put the original front page back.
 */
add_action( 'after_switch_theme', 'tc_restore_v3_front_page' );
function tc_restore_v3_front_page() {
	$previous = get_option( 'tc_previous_front' );
	if ( ! is_array( $previous ) ) {
		return;
	}
	update_option( 'show_on_front', $previous[0] ? $previous[0] : 'posts' );
	update_option( 'page_on_front', (int) $previous[1] );
	delete_option( 'tc_previous_front' );
}
