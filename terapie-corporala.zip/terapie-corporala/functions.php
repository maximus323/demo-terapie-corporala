<?php
/**
 * Terapie Corporală — block theme with the same structure as the old site
 * (Twenty Sixteen): title + header photo, page content, sidebar with the
 * page list. No menu bar. Pages, header, sidebar and footer are edited in
 * Appearance → Editor; widgets in Appearance → Widgets.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

define( 'TC_VERSION', '4.7.1' );
define( 'TC_DIR', get_template_directory() );
define( 'TC_URI', get_template_directory_uri() );

require_once TC_DIR . '/inc/settings.php';
require_once TC_DIR . '/inc/icons.php';
require_once TC_DIR . '/inc/blocks.php';

add_action( 'after_setup_theme', 'tc_setup' );
function tc_setup() {
	load_theme_textdomain( 'tc', TC_DIR . '/languages' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
}

/* Theme CSS on the site and inside the editor. Fonts are self-hosted via theme.json. */
add_action( 'enqueue_block_assets', 'tc_block_assets' );
function tc_block_assets() {
	wp_enqueue_style( 'tc-main', get_stylesheet_uri(), array(), TC_VERSION );
	// Text of the "Apasă aici" label on the treatment buttons (Setări → Date cabinet).
	$apasa = str_replace( array( '\\', '"', "\n", '<' ), array( '\\\\', '\\"', ' ', '' ), (string) tc_opt( 'text_apasa' ) );
	wp_add_inline_style( 'tc-main', ':root{--tc-apasa:"' . $apasa . '"}' );
}

/*
 * Shortcodes inside Custom HTML / Text widgets (e.g. the reviews widget
 * "[trustindex no-registration=facebook]") must run, as they did with the
 * old theme. The checks avoid adding the filter twice.
 */
add_action( 'init', 'tc_widget_shortcodes' );
function tc_widget_shortcodes() {
	foreach ( array( 'widget_custom_html_content', 'widget_text', 'widget_text_content' ) as $hook ) {
		if ( false === has_filter( $hook, 'do_shortcode' ) ) {
			add_filter( $hook, 'do_shortcode', 11 );
		}
	}
}

/*
 * Widget areas with the same IDs as Twenty Sixteen, so the client's existing
 * widgets (page list, map, reviews, counters) move over untouched when the
 * theme is switched.
 */
add_action( 'widgets_init', 'tc_widget_areas' );
function tc_widget_areas() {
	$areas = array(
		'sidebar-1' => array( 'Bară laterală', 'Apare lângă conținut pe calculator și sub conținut pe telefon.' ),
		'sidebar-2' => array( 'Sub conținut 1', 'Apare sub conținutul fiecărei pagini.' ),
		'sidebar-3' => array( 'Sub conținut 2', 'Apare sub „Sub conținut 1”.' ),
	);
	foreach ( $areas as $id => $area ) {
		register_sidebar(
			array(
				'id'            => $id,
				'name'          => $area[0],
				'description'   => $area[1],
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
}

/* Block styles the client can pick in the editor. */
add_action( 'init', 'tc_block_styles' );
function tc_block_styles() {
	register_block_style( 'core/button', array( 'name' => 'auriu', 'label' => __( 'Auriu', 'tc' ) ) );
	register_block_style( 'core/button', array( 'name' => 'contur', 'label' => __( 'Contur', 'tc' ) ) );
	register_block_style( 'core/group', array( 'name' => 'caseta', 'label' => __( 'Casetă albă', 'tc' ) ) );
}

/*
 * Floating "Sună acum" + WhatsApp buttons, same place as the old plugins
 * (call bottom-left, WhatsApp bottom-right). Both switches are in
 * Setări → Date cabinet → Opțiuni.
 */
function tc_show_floating_buttons() {
	return (bool) apply_filters( 'tc_floating_buttons', tc_opt_on( 'opt_butoane' ) );
}

add_filter( 'body_class', 'tc_body_class' );
function tc_body_class( $classes ) {
	if ( tc_show_floating_buttons() ) {
		$classes[] = 'tc-fab-on';
	}
	if ( tc_opt_on( 'opt_ascunde_pluginuri' ) ) {
		$classes[] = 'tc-hide-plugin-fab';
	}
	if ( tc_show_floating_buttons() && tc_review_links() ) {
		$classes[] = 'tc-reviews-on';
	}
	return $classes;
}

/*
 * Small "Vezi recenzii pe Google / Facebook" buttons shown above "Sună acum".
 * Links, texts and the on/off switch: Setări → Date cabinet → Recenzii.
 */
function tc_review_links() {
	if ( ! tc_opt_on( 'opt_recenzii' ) ) {
		return array();
	}
	$links = array();
	foreach ( array( 'google', 'facebook' ) as $site ) {
		$url = tc_opt( 'recenzii_' . $site );
		if ( 'facebook' === $site && tc_fb_reviews_on_site() ) {
			$url = '#recenzii-facebook';
		}
		if ( $url ) {
			$links[ $site ] = array( $url, tc_opt( 'text_recenzii_' . $site ) );
		}
	}
	return $links;
}

/*
 * On phones the Facebook app ignores links to a page's reviews and opens the
 * page's home, so by default the Facebook button opens the reviews right here,
 * in a window on the site, with a button to see them all on Facebook.
 */
function tc_fb_reviews_on_site() {
	return tc_opt_on( 'opt_fb_pe_site' ) && tc_fb_reviews();
}

/*
 * The Trustindex reviews widget arrives hidden (inline opacity:0/height:0) and
 * its loader is meant to reveal it. With page-speed plugins that delay scripts
 * (10Web Booster) that can fail, leaving an empty box. If it is still hidden a
 * little after load, make sure its stylesheet is loaded, then show it.
 */
/*
 * The "Apasă aici pentru a afla cât costă" button (<details>) must open on the
 * FIRST tap. Speed plugins that delay JavaScript (10Web Booster) catch the
 * first tap and replay it, which opens and closes it at once. This tiny
 * script is excluded from delaying (data-two-no-delay & co.), toggles on the
 * real tap only and ignores replayed (synthetic) clicks.
 */
add_action( 'wp_head', 'tc_details_first_tap', 1 );
function tc_details_first_tap() {
	?>
	<script data-two-no-delay data-no-optimize="1" data-no-defer="1" data-cfasync="false">
	window.addEventListener('click', function (e) {
		var s = e.target && e.target.closest ? e.target.closest('summary.anunt-buton') : null;
		if (!s) { return; }
		e.preventDefault();
		if (e.isTrusted) { s.parentNode.open = !s.parentNode.open; }
	}, true);
	</script>
	<?php
}

add_action( 'wp_footer', 'tc_reveal_review_widgets', 30 );
function tc_reveal_review_widgets() {
	?>
	<script>
	(function () {
		var done = false;
		function reveal() {
			if (done) { return; }
			var widgets = document.querySelectorAll('.ti-widget[data-trustindex-widget]');
			if (!widgets.length) { done = true; return; }
			widgets.forEach(function (w) {
				if (w.getBoundingClientRect().height > 0) { return; }
				var url = (w.getAttribute('data-css-url') || '').split('?')[0];
				var loaded = !url || Array.prototype.some.call(document.styleSheets, function (s) { return s.href && s.href.split('?')[0] === url; });
				if (loaded) { w.removeAttribute('style'); return; }
				var l = document.createElement('link');
				l.rel = 'stylesheet';
				l.href = w.getAttribute('data-css-url');
				l.onload = function () { w.removeAttribute('style'); };
				document.head.appendChild(l);
			});
			done = true;
		}
		function later() { setTimeout(reveal, 2500); }
		if (document.readyState === 'complete') { later(); } else { window.addEventListener('load', later); }
		['scroll', 'touchstart', 'mousemove'].forEach(function (ev) {
			window.addEventListener(ev, function h() { window.removeEventListener(ev, h); later(); }, { passive: true });
		});
	})();
	</script>
	<?php
}

add_action( 'wp_footer', 'tc_fb_reviews_dialog', 20 );
function tc_fb_reviews_dialog() {
	if ( ! tc_show_floating_buttons() || ! tc_opt_on( 'opt_recenzii' ) || ! tc_fb_reviews_on_site() ) {
		return;
	}
	$fb_url = tc_opt( 'recenzii_facebook' );
	?>
	<dialog id="recenzii-facebook" class="rev-dialog" aria-labelledby="rev-dialog-titlu">
		<div class="rev-dialog-head">
			<?php echo tc_review_logo( 'facebook' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div>
				<h2 id="rev-dialog-titlu"><?php echo esc_html( tc_opt( 'recenzii_fb_titlu' ) ); ?></h2>
				<?php if ( tc_opt( 'recenzii_fb_subtitlu' ) ) : ?>
					<p><?php echo esc_html( tc_opt( 'recenzii_fb_subtitlu' ) ); ?></p>
				<?php endif; ?>
			</div>
			<a class="rev-close" href="#inchide-recenzii" role="button" aria-label="<?php esc_attr_e( 'Închide', 'tc' ); ?>">×</a>
		</div>
		<ul class="rev-list">
			<?php foreach ( tc_fb_reviews() as $review ) : ?>
				<li class="rev-card">
					<p class="rev-name"><?php echo esc_html( $review[0] ); ?> <span><?php esc_html_e( 'recomandă', 'tc' ); ?></span></p>
					<?php foreach ( $review[1] as $paragraph ) : ?>
						<p><?php echo esc_html( $paragraph ); ?></p>
					<?php endforeach; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $fb_url ) : ?>
			<div class="rev-dialog-foot">
				<a class="rev-all" href="<?php echo esc_url( $fb_url ); ?>" target="_blank" rel="noopener"><?php echo tc_review_logo( 'facebook' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'text_fb_toate' ) ); ?></a>
			</div>
		<?php endif; ?>
	</dialog>
	<script>
	(function () {
		var d = document.getElementById('recenzii-facebook');
		if (!d || typeof d.showModal !== 'function') { return; }
		var open = function () { if (!d.open) { d.showModal(); } d.querySelector('.rev-list').scrollTop = 0; };
		// Capture phase: runs before other click handlers (e.g. page builders, Playground).
		window.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('a[href="#recenzii-facebook"], a[href="#inchide-recenzii"]');
			if (!a) { return; }
			e.preventDefault();
			e.stopPropagation();
			if (a.getAttribute('href') === '#recenzii-facebook') { open(); } else { d.close(); }
		}, true);
		d.addEventListener('click', function (e) { if (e.target === d) { d.close(); } });
		if (location.hash === '#recenzii-facebook') { open(); }
		window.addEventListener('hashchange', function () { if (location.hash === '#recenzii-facebook') { open(); } });
	})();
	</script>
	<?php
}

function tc_review_logo( $site ) {
	if ( 'google' === $site ) {
		return '<svg class="rev-logo" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 0 1-2.4 3.6v3h3.9c2.3-2.1 3.5-5.2 3.5-8.8z"/><path fill="#34A853" d="M12 24c3.2 0 6-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2-3.1 0-5.7-2.1-6.6-4.9H1.4v3.1A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.4 14.4a7.2 7.2 0 0 1 0-4.7V6.6h-4a12 12 0 0 0 0 10.9l4-3.1z"/><path fill="#EA4335" d="M12 4.8c1.7 0 3.3.6 4.5 1.8l3.4-3.4A12 12 0 0 0 1.4 6.6l4 3.1C6.3 6.9 8.9 4.8 12 4.8z"/></svg>';
	}
	return '<svg class="rev-logo" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#1877F2"/><path fill="#fff" d="M13.4 19.5v-6.2h2.1l.3-2.5h-2.4V9.3c0-.7.2-1.2 1.2-1.2h1.3V5.9c-.2 0-1-.1-1.9-.1-1.9 0-3.2 1.2-3.2 3.3v1.8H8.7v2.5h2.1v6.2h2.6z"/></svg>';
}

add_action( 'wp_footer', 'tc_floating_actions' );
function tc_floating_actions() {
	if ( ! tc_show_floating_buttons() ) {
		return;
	}
	echo '<div class="fab-left">';
	foreach ( tc_review_links() as $site => $link ) {
		printf(
			'<a class="fab-review fab-review-%1$s" href="%2$s"%6$s>%3$s<span class="rev-text">%4$s</span><span class="rev-star" aria-hidden="true">★</span><span class="rev-mini" aria-hidden="true">%5$s</span></a>',
			esc_attr( $site ),
			'#' === substr( $link[0], 0, 1 ) ? esc_attr( $link[0] ) : esc_url( $link[0] ),
			tc_review_logo( $site ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( $link[1] ),
			esc_html( tc_opt( 'text_recenzii_scurt' ) ),
			'#' === substr( $link[0], 0, 1 ) ? ' aria-haspopup="dialog"' : ' target="_blank" rel="noopener"'
		);
	}
	printf(
		'<a class="fab fab-call" href="%1$s">%2$s<span>%3$s</span></a>',
		esc_attr( tc_tel_href() ),
		tc_icon( 'phone' ), // phpcs:ignore WordPress.Security.EscapeOutput
		esc_html( tc_opt( 'text_suna' ) )
	);
	echo '</div>';
	$wa = tc_wa_href();
	if ( $wa ) {
		printf(
			'<a class="fab fab-wa" href="%1$s" target="_blank" rel="noopener">%2$s<span>%3$s</span></a>',
			esc_url( $wa ),
			tc_icon( 'wa' ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( tc_opt( 'text_whatsapp' ) )
		);
	}
}

function tc_tel_href() {
	$digits = preg_replace( '/[^0-9+]/', '', tc_opt( 'telefon' ) );
	if ( 0 === strpos( $digits, '0' ) ) {
		$digits = '+4' . $digits;
	}
	return 'tel:' . $digits;
}

function tc_wa_href() {
	$digits = preg_replace( '/[^0-9]/', '', tc_opt( 'whatsapp' ) );
	return $digits ? 'https://wa.me/' . $digits : '';
}

/*
 * Lines in the page text that start with the 👉 emoji (e.g. "👉 durere de spate"
 * on the front page) become "call us" links, so a patient can tap the
 * complaint and phone the clinic. Matches the emoji as a character or as the
 * Facebook emoji image (…/1f449.png) the old pages use. Switch: Setări →
 * Date cabinet → Opțiuni.
 */
add_filter( 'the_content', 'tc_emoji_tel_links', 20 );
function tc_emoji_tel_links( $html ) {
	if ( ! apply_filters( 'tc_emoji_tel_links', tc_opt_on( 'opt_emoji' ) ) || ( false === strpos( $html, '1f449' ) && false === strpos( $html, "\u{1F449}" ) ) ) {
		return $html;
	}
	$pattern = '#<(div|p)([^>]*)>\s*((?:<span[^>]*>)?\s*(?:<img[^>]*1f449[^>]*>|\x{1F449})\s*(?:</span>)?)\s*([^<]+?)\s*</\1>#u';
	$tel     = esc_attr( tc_tel_href() );
	$label   = esc_attr( tc_opt( 'text_suna' ) );
	$result  = preg_replace(
		$pattern,
		'<$1$2><a class="tel-line" href="' . $tel . '" aria-label="$4 – ' . $label . '">$3 $4</a></$1>',
		$html
	);
	return null === $result ? $html : $result;
}

/*
 * Old links with a misplaced hyphen (e.g. /rtms-stimularea-.../ for the page
 * /rtmsstimularea-.../) give "page not found". When exactly one published page
 * has the same address once hyphens are ignored, send the visitor there (301).
 */
add_action( 'template_redirect', 'tc_redirect_hyphen_typos' );
function tc_redirect_hyphen_typos() {
	if ( ! is_404() || ! tc_opt_on( 'opt_redirect' ) ) {
		return;
	}
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$slug = sanitize_title( basename( $path ) );
	if ( '' === $slug || strlen( $slug ) < 6 ) {
		return;
	}
	$key     = str_replace( '-', '', $slug );
	$matches = array();
	foreach ( get_pages( array( 'post_status' => 'publish' ) ) as $page ) {
		if ( str_replace( '-', '', $page->post_name ) === $key ) {
			$matches[] = $page->ID;
		}
	}
	if ( 1 === count( $matches ) ) {
		wp_safe_redirect( get_permalink( $matches[0] ), 301 );
		exit;
	}
}

/*
 * Images that ship with the theme (e.g. the header photo) are written in the
 * templates as "/wp-content/themes/terapie-corporala/...". That only works when
 * WordPress sits at the root of the domain, so turn it into the theme's real
 * address (works in a sub-folder, on staging and in the Playground demo).
 */
add_filter( 'render_block_core/image', 'tc_theme_image_urls' );
function tc_theme_image_urls( $html ) {
	$relative = '/wp-content/themes/' . get_template() . '/';
	if ( false === strpos( $html, $relative ) ) {
		return $html;
	}
	return str_replace(
		array( 'src="' . $relative, "src='" . $relative ),
		array( 'src="' . trailingslashit( get_template_directory_uri() ), "src='" . trailingslashit( get_template_directory_uri() ) ),
		$html
	);
}

/*
 * Version 3 of this theme replaced the front page with an "Acasă" page.
 * If that happened on this site, put the original front page back.
 */
add_action( 'after_switch_theme', 'tc_restore_v3_front_page' );
function tc_restore_v3_front_page() {
	$previous = get_option( 'tc_previous_front' );
	if ( ! is_array( $previous ) ) {
		return;
	}
	update_option( 'show_on_front', $previous[0] ? $previous[0] : 'posts' );
	update_option( 'page_on_front', (int) $previous[1] );
	delete_option( 'tc_previous_front' );
}
