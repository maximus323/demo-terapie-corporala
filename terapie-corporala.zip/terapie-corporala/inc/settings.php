<?php
/**
 * Setări → Date cabinet: clinic details, the texts on the theme's buttons and
 * on/off switches for the theme's automatic behaviours. Everything else is
 * edited in the pages, the Site Editor and Appearance → Widgets.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

const TC_OPTION = 'tc_cabinet';

/* The clinic's own Google Maps pin (same place as the "Cum ajungi la fizioterapie!" widget), road view. */
const TC_MAP_EMBED = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2693.1982733411096!2d26.118872511587966!3d44.433097970955195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40b1fd00a7568307%3A0x4f56d606dfaa80b1!2sFizioterapie%20Laser%20Rece!5e0!3m2!1sro!2sro!4v1734091029322!5m2!1sro!2sro';

/* Fields that may be saved empty on purpose (empty = hidden). */
const TC_MAY_BE_EMPTY = array( 'whatsapp', 'zona', 'anunt_titlu', 'recenzii_google', 'recenzii_facebook' );

/**
 * Field definitions: key => [ label, default, type, group ].
 * Types: text, textarea, url, checkbox.
 */
function tc_settings() {
	return array(
		'telefon'               => array( 'Telefon', '0723 428 414', 'text', 'Contact' ),
		'whatsapp'              => array( 'Număr WhatsApp (internațional, fără +; gol = fără buton WhatsApp)', '40723428414', 'text', 'Contact' ),
		'adresa'                => array( 'Adresă', 'Calea Călărașilor 137, Sector 3, București', 'text', 'Contact' ),
		'zona'                  => array( 'Reper (gol = nu apare)', 'zona Hala Traian', 'text', 'Contact' ),

		'opt_recenzii'          => array( 'Arată butoanele mici „Vezi recenzii” deasupra butonului de apel', '1', 'checkbox', 'Recenzii' ),
		'recenzii_google'       => array( 'Link recenzii Google (gol = fără buton Google)', 'https://www.google.com/maps?cid=5716992102004064433', 'url', 'Recenzii' ),
		'text_recenzii_google'  => array( 'Textul butonului Google', 'Vezi recenzii pe Google', 'text', 'Recenzii' ),
		'recenzii_facebook'     => array( 'Link recenzii Facebook (gol = fără buton Facebook)', 'https://www.facebook.com/FizioterapieRecuperare/reviews', 'url', 'Recenzii' ),
		'text_recenzii_facebook' => array( 'Textul butonului Facebook', 'Vezi recenzii pe Facebook', 'text', 'Recenzii' ),
		'text_recenzii_scurt'   => array( 'Pe telefon: cuvântul scurt sub logo', 'Recenzii', 'text', 'Recenzii' ),

		'program'               => array( 'Program (o zi sau un grup de zile pe rând, ex.: „Luni – Vineri: 11:00 – 20:30”)', 'Luni – Vineri: 11:00 – 20:30', 'textarea', 'Program și hartă' ),
		'harta_url'             => array( 'Link pentru butonul „Cum ajung aici” (Google Maps)', 'https://www.google.com/maps/dir/?api=1&destination=Calea+Calarasilor+137+Bucuresti', 'url', 'Program și hartă' ),
		'harta_embed'           => array( 'Hartă pe site (Google Maps → Distribuiți → Încorporați o hartă → lipiți codul aici)', TC_MAP_EMBED, 'url', 'Program și hartă' ),

		'text_suna'             => array( 'Butonul de apel', 'Sună acum', 'text', 'Texte pe butoane' ),
		'text_whatsapp'         => array( 'Butonul WhatsApp', 'WhatsApp', 'text', 'Texte pe butoane' ),
		'text_apasa'            => array( 'Butonul din lista de tratamente', 'Apasă aici ›', 'text', 'Texte pe butoane' ),
		'text_ruta'             => array( 'Butonul pentru hartă', 'Cum ajung aici', 'text', 'Texte pe butoane' ),
		'eticheta_adresa'       => array( '„Unde ne găsești”: eticheta adresei', 'Adresa', 'text', 'Texte pe butoane' ),
		'eticheta_program'      => array( '„Unde ne găsești”: eticheta programului', 'Program', 'text', 'Texte pe butoane' ),
		'eticheta_telefon'      => array( '„Unde ne găsești”: eticheta telefonului', 'Telefon', 'text', 'Texte pe butoane' ),

		'opt_butoane'           => array( 'Arată butoanele plutitoare „Sună acum” și WhatsApp (jos, pe fiecare pagină)', '1', 'checkbox', 'Opțiuni' ),
		'opt_ascunde_pluginuri' => array( 'Ascunde butoanele vechi ale pluginurilor Call Now Button și Click to Chat (ca să nu apară de două ori)', '1', 'checkbox', 'Opțiuni' ),
		'opt_emoji'             => array( 'Rândurile din pagini care încep cu 👉 sună la cabinet când sunt atinse', '1', 'checkbox', 'Opțiuni' ),
		'opt_redirect'          => array( 'Corectează automat linkurile vechi cu o cratimă în plus (ex. /rtms-stimularea-…/)', '1', 'checkbox', 'Opțiuni' ),

		'anunt_on'              => array( 'Arată anunțul (caseta evidențiată de la începutul paginii)', '1', 'checkbox', 'Anunț important' ),
		'anunt_peste_tot'       => array( 'Arată anunțul pe toate paginile (nebifat = doar pe prima pagină)', '0', 'checkbox', 'Anunț important' ),
		'anunt_titlu'           => array( 'Titlul anunțului (gol = fără titlu)', '', 'text', 'Anunț important' ),
		'anunt_text'            => array( 'Textul anunțului: un rând pe linie; „text — preț” afișează prețul mare în dreapta', "Plata pentru 5 ședințe — 750 lei\nO ședință (în pachetul de 5) — 150 lei / zonă\nPlata zilnică, pe ședință — 200 lei", 'textarea', 'Anunț important' ),
	);
}

function tc_opt( $key ) {
	static $saved = null;
	if ( null === $saved ) {
		$saved = (array) get_option( TC_OPTION, array() );
	}
	if ( isset( $saved[ $key ] ) && '' !== $saved[ $key ] ) {
		return $saved[ $key ];
	}
	if ( array_key_exists( $key, $saved ) && in_array( $key, TC_MAY_BE_EMPTY, true ) ) {
		return '';
	}
	$fields = tc_settings();
	return isset( $fields[ $key ] ) ? $fields[ $key ][1] : '';
}

/* True when a checkbox option is switched on. */
function tc_opt_on( $key ) {
	return '1' === (string) tc_opt( $key );
}

/**
 * Opening hours as [ [ days, hours ], ... ], one per line of the "Program" field.
 */
function tc_program_rows() {
	$rows = array();
	foreach ( preg_split( '/\r\n|\r|\n|;/', (string) tc_opt( 'program' ) ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts  = preg_split( '/:\s+|,\s+/', $line, 2 );
		$rows[] = 2 === count( $parts ) ? array( trim( $parts[0] ), trim( $parts[1] ) ) : array( $line, '' );
	}
	return $rows;
}

/**
 * Announcement lines as [ [ text, price ], ... ]: "text — price" (or "text: price")
 * splits into a label and a big price; a line without a dash stays plain text.
 */
function tc_anunt_rows() {
	$rows = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) tc_opt( 'anunt_text' ) ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts  = preg_split( '/\s+[—–-]\s+|:\s+/u', $line, 2 );
		$rows[] = 2 === count( $parts ) ? array( trim( $parts[0] ), trim( $parts[1] ) ) : array( $line, '' );
	}
	return $rows;
}

add_action( 'admin_menu', 'tc_settings_menu' );
function tc_settings_menu() {
	add_options_page( __( 'Date cabinet', 'tc' ), __( 'Date cabinet', 'tc' ), 'manage_options', 'tc-cabinet', 'tc_settings_page' );
}

add_action( 'admin_init', 'tc_settings_register' );
function tc_settings_register() {
	register_setting(
		'tc_cabinet_group',
		TC_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'tc_settings_sanitize',
			'default'           => array(),
		)
	);
}

function tc_settings_sanitize( $input ) {
	$clean = array();
	$input = is_array( $input ) ? $input : array();
	foreach ( tc_settings() as $key => $def ) {
		$raw = isset( $input[ $key ] ) ? (string) $input[ $key ] : '';
		switch ( $def[2] ) {
			case 'checkbox':
				$clean[ $key ] = '' === $raw ? '0' : '1';
				break;
			case 'textarea':
				$clean[ $key ] = sanitize_textarea_field( $raw );
				break;
			case 'url':
				$clean[ $key ] = esc_url_raw( $raw );
				break;
			default:
				$clean[ $key ] = sanitize_text_field( $raw );
		}
	}
	if ( '' !== $clean['whatsapp'] ) {
		$clean['whatsapp'] = preg_replace( '/[^0-9]/', '', $clean['whatsapp'] );
	}
	$clean['harta_embed'] = tc_clean_map_embed( isset( $input['harta_embed'] ) ? (string) $input['harta_embed'] : '' );
	return $clean;
}

/**
 * Only a Google Maps embed address is allowed for the map. Accepts the bare
 * address or the whole <iframe> code copied from Google Maps.
 */
function tc_clean_map_embed( $raw ) {
	if ( preg_match( '/src=["\']([^"\']+)["\']/i', $raw, $m ) ) {
		$raw = html_entity_decode( $m[1] );
	}
	$url = esc_url_raw( trim( $raw ) );
	return 0 === strpos( $url, 'https://www.google.com/maps/embed' ) ? $url : '';
}

function tc_settings_field( $key, $def ) {
	$id   = 'tc_' . $key;
	$name = TC_OPTION . '[' . $key . ']';
	if ( 'checkbox' === $def[2] ) {
		printf(
			'<label for="%1$s"><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s> %4$s</label>',
			esc_attr( $id ),
			esc_attr( $name ),
			checked( tc_opt_on( $key ), true, false ),
			esc_html( $def[0] )
		);
		return;
	}
	if ( 'textarea' === $def[2] ) {
		printf( '<textarea class="large-text" rows="3" id="%1$s" name="%2$s">%3$s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( tc_opt( $key ) ) );
		return;
	}
	printf(
		'<input class="regular-text" type="%1$s" id="%2$s" name="%3$s" value="%4$s">',
		'url' === $def[2] ? 'url' : 'text',
		esc_attr( $id ),
		esc_attr( $name ),
		esc_attr( tc_opt( $key ) )
	);
}

function tc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$groups = array();
	foreach ( tc_settings() as $key => $def ) {
		$groups[ $def[3] ][ $key ] = $def;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Date cabinet', 'tc' ); ?></h1>
		<p><?php esc_html_e( 'Datele cabinetului, textele de pe butoanele temei și opțiunile ei. Apar în secțiunea «Unde ne găsești» (sub fiecare pagină), în butoanele plutitoare și în subsol. Textele și fotografiile paginilor se modifică direct în pagini; widgeturile în Aspect → Widgeturi; culorile și fonturile în Aspect → Editor → Stiluri.', 'tc' ); ?></p>
		<p><?php esc_html_e( 'Un câmp de text lăsat gol revine la textul inițial.', 'tc' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'tc_cabinet_group' ); ?>
			<?php foreach ( $groups as $group => $fields ) : ?>
				<h2 class="title"><?php echo esc_html( $group ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $def ) : ?>
						<tr>
							<th scope="row">
								<?php if ( 'checkbox' !== $def[2] ) : ?>
									<label for="tc_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $def[0] ); ?></label>
								<?php endif; ?>
							</th>
							<td><?php tc_settings_field( $key, $def ); ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
