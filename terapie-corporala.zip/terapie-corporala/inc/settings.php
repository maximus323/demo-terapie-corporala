<?php
/**
 * Clinic details (Setări → Date cabinet): used by the contact, booking and
 * WhatsApp parts of the site. Everything else is edited in the blocks.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

const TC_OPTION = 'tc_cabinet';

/**
 * Field definitions: key => [ label, default, type ].
 */
function tc_settings() {
	return array(
		'telefon'          => array( 'Telefon', '0723 428 414', 'text' ),
		'whatsapp'         => array( 'Număr WhatsApp (internațional, fără +; gol = ascuns)', '40723428414', 'text' ),
		'adresa'           => array( 'Adresă', 'Calea Călărașilor 137, Sector 3, București', 'text' ),
		'zona'             => array( 'Reper', 'zona Hala Traian', 'text' ),
		'program'          => array( 'Program', 'Luni–Vineri, 11:00–20:30', 'text' ),
		'harta_url'        => array( 'Link Google Maps', 'https://www.google.com/maps/search/?api=1&query=Calea+Calarasilor+137+Bucuresti', 'url' ),
		'bara_text'        => array( 'Text în bara de sus', 'Cabinet de fizioterapie și terapia durerii', 'text' ),
		'email_programari' => array( 'Email unde ajung cererile de programare (gol = emailul administratorului)', '', 'email' ),
	);
}

function tc_opt( $key ) {
	static $saved = null;
	if ( null === $saved ) {
		$saved = (array) get_option( TC_OPTION, array() );
	}
	if ( isset( $saved[ $key ] ) && '' !== $saved[ $key ] ) {
		return $saved[ $key ];
	}
	$fields = tc_settings();
	// These may be deliberately left empty once saved.
	if ( array_key_exists( $key, $saved ) && in_array( $key, array( 'whatsapp', 'email_programari', 'bara_text', 'zona' ), true ) ) {
		return '';
	}
	return isset( $fields[ $key ] ) ? $fields[ $key ][1] : '';
}

add_action( 'admin_menu', 'tc_settings_menu' );
function tc_settings_menu() {
	add_options_page( __( 'Date cabinet', 'tc' ), __( 'Date cabinet', 'tc' ), 'manage_options', 'tc-cabinet', 'tc_settings_page' );
}

add_action( 'admin_init', 'tc_settings_register' );
function tc_settings_register() {
	register_setting(
		'tc_cabinet_group',
		TC_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'tc_settings_sanitize',
			'default'           => array(),
		)
	);
}

function tc_settings_sanitize( $input ) {
	$clean = array();
	$input = is_array( $input ) ? $input : array();
	foreach ( tc_settings() as $key => $def ) {
		$raw = isset( $input[ $key ] ) ? (string) $input[ $key ] : '';
		switch ( $def[2] ) {
			case 'url':
				$clean[ $key ] = esc_url_raw( $raw );
				break;
			case 'email':
				$clean[ $key ] = sanitize_email( $raw );
				break;
			default:
				$clean[ $key ] = sanitize_text_field( $raw );
		}
	}
	if ( '' !== $clean['whatsapp'] ) {
		$clean['whatsapp'] = preg_replace( '/[^0-9]/', '', $clean['whatsapp'] );
	}
	return $clean;
}

function tc_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Date cabinet', 'tc' ); ?></h1>
		<p><?php esc_html_e( 'Aceste date apar în bara de sus, la contact, în formularul de programare și în butonul WhatsApp. Textele și fotografiile paginilor se modifică direct în editor.', 'tc' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'tc_cabinet_group' ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( tc_settings() as $key => $def ) : ?>
					<tr>
						<th scope="row"><label for="tc_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $def[0] ); ?></label></th>
						<td><input class="regular-text" type="<?php echo esc_attr( 'url' === $def[2] ? 'url' : ( 'email' === $def[2] ? 'email' : 'text' ) ); ?>" id="tc_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( TC_OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( tc_opt( $key ) ); ?>"></td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
