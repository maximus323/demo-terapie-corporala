<?php
/**
 * Appointment request form: renders the form and emails the request.
 *
 * Nothing is stored in the database (health-related personal data).
 * Spam protection: honeypot field + per-IP rate limit. A nonce is not used on
 * purpose: the form is public (no logged-in action to forge) and page caching
 * would serve expired nonces, silently breaking submissions.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

const TC_BOOKING_MAX_PER_HOUR = 3;
const TC_BOOKING_OTHER        = 'Altceva';

function tc_booking_days() {
	return array( 'Oricând', 'Luni', 'Marți', 'Miercuri', 'Joi', 'Vineri' );
}

function tc_booking_intervals() {
	return array( '11:00–14:00', '14:00–17:00', '17:00–20:30' );
}

function tc_booking_problems() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'problema',
			'hide_empty' => false,
			'orderby'    => 'term_id',
			'fields'     => 'names',
		)
	);
	// Stored names are HTML-encoded ("&amp;"); decode so they match the submitted value.
	$names = is_wp_error( $terms ) ? array() : array_map( 'wp_specialchars_decode', $terms );
	$names[] = TC_BOOKING_OTHER;
	return $names;
}

/**
 * Status message after a submission, keyed by ?tc_status=.
 */
function tc_booking_status_message() {
	$status   = isset( $_GET['tc_status'] ) ? sanitize_key( wp_unslash( $_GET['tc_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$messages = array(
		'ok'      => array( 'ok', __( 'Mulțumim! Am primit cererea și vă sunăm în cel mai scurt timp.', 'tc' ) ),
		'invalid' => array( 'err', __( 'Vă rugăm completați numele, un telefon valid și bifați acordul pentru date.', 'tc' ) ),
		'limit'   => array( 'err', __( 'Ați trimis deja mai multe cereri. Vă rugăm să ne sunați direct.', 'tc' ) ),
		'eroare'  => array( 'err', __( 'Cererea nu a putut fi trimisă. Vă rugăm să ne sunați direct.', 'tc' ) ),
	);
	return isset( $messages[ $status ] ) ? $messages[ $status ] : null;
}

function tc_booking_form() {
	$status = tc_booking_status_message();
	?>
	<form class="booking-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-reveal>
		<input type="hidden" name="action" value="tc_programare">
		<h3 class="form-title"><?php esc_html_e( 'Cerere de programare', 'tc' ); ?></h3>
		<div class="hp" aria-hidden="true">
			<label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
		</div>
		<?php if ( $status ) : ?>
			<p class="notice notice-<?php echo esc_attr( $status[0] ); ?>" role="status"><?php echo esc_html( $status[1] ); ?></p>
		<?php endif; ?>
		<label class="f"><?php esc_html_e( 'Ce vă doare?', 'tc' ); ?>
			<select name="problema">
				<?php foreach ( tc_booking_problems() as $p ) : ?>
					<option><?php echo esc_html( $p ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<div class="f2">
			<label class="f"><?php esc_html_e( 'Zi preferată', 'tc' ); ?>
				<select name="zi">
					<?php foreach ( tc_booking_days() as $d ) : ?>
						<option><?php echo esc_html( $d ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="f"><?php esc_html_e( 'Interval', 'tc' ); ?>
				<select name="interval">
					<?php foreach ( tc_booking_intervals() as $i ) : ?>
						<option><?php echo esc_html( $i ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		</div>
		<div class="f2">
			<label class="f"><?php esc_html_e( 'Nume', 'tc' ); ?><input type="text" name="nume" autocomplete="name" required maxlength="80"></label>
			<label class="f"><?php esc_html_e( 'Telefon', 'tc' ); ?><input type="tel" name="telefon" autocomplete="tel" inputmode="tel" required maxlength="20"></label>
		</div>
		<label class="consent">
			<input type="checkbox" name="acord" value="1" required>
			<span><?php esc_html_e( 'Sunt de acord cu prelucrarea datelor pentru a fi contactat(ă) în vederea programării.', 'tc' ); ?>
				<?php if ( get_privacy_policy_url() ) : ?>
					<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Politica de confidențialitate', 'tc' ); ?></a>
				<?php endif; ?>
			</span>
		</label>
		<button class="tc-btn tc-btn-gold" type="submit"><?php esc_html_e( 'Trimite cererea', 'tc' ); ?></button>
	</form>
	<?php
}

add_action( 'admin_post_nopriv_tc_programare', 'tc_handle_booking' );
add_action( 'admin_post_tc_programare', 'tc_handle_booking' );
function tc_handle_booking() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- see file header.
	$back = remove_query_arg( 'tc_status', wp_get_referer() ? wp_get_referer() : home_url( '/' ) );

	// Honeypot: bots fill every field. Pretend success, send nothing.
	if ( ! empty( $_POST['website'] ) ) {
		tc_booking_redirect( $back, 'ok' );
	}

	// Behind a proxy/CDN, REMOTE_ADDR is the proxy for everyone: hook this filter to
	// return the real client IP from the proxy's trusted header (never raw X-Forwarded-For).
	$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$ip_key = 'tc_bk_' . md5( (string) apply_filters( 'tc_booking_client_ip', $remote ) );
	$count  = (int) get_transient( $ip_key );
	if ( $count >= TC_BOOKING_MAX_PER_HOUR ) {
		tc_booking_redirect( $back, 'limit' );
	}

	$field = static function ( $name, $max = 80 ) {
		$value = isset( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : '';
		return mb_substr( $value, 0, $max );
	};
	$nume     = $field( 'nume' );
	$telefon  = $field( 'telefon', 20 );
	$problema = $field( 'problema' );
	$zi       = $field( 'zi' );
	$interval = $field( 'interval' );
	$acord    = ! empty( $_POST['acord'] );
	// phpcs:enable

	$valid = $acord
		&& mb_strlen( $nume ) >= 2
		&& preg_match( '/^[0-9 +().\-]{8,20}$/', $telefon )
		&& in_array( $problema, tc_booking_problems(), true )
		&& in_array( $zi, tc_booking_days(), true )
		&& in_array( $interval, tc_booking_intervals(), true );
	if ( ! $valid ) {
		tc_booking_redirect( $back, 'invalid' );
	}

	set_transient( $ip_key, $count + 1, HOUR_IN_SECONDS );

	$to      = tc_opt( 'email_programari' ) ? tc_opt( 'email_programari' ) : get_option( 'admin_email' );
	$subject = sprintf( 'Cerere programare: %s', $nume );
	$body    = implode(
		"\n",
		array(
			'Cerere nouă de programare de pe site:',
			'',
			'Nume: ' . $nume,
			'Telefon: ' . $telefon,
			'Problemă: ' . $problema,
			'Zi preferată: ' . $zi,
			'Interval: ' . $interval,
			'',
			'Pacientul și-a dat acordul pentru prelucrarea datelor în vederea programării.',
		)
	);
	$sent = wp_mail( $to, $subject, $body );

	tc_booking_redirect( $back, $sent ? 'ok' : 'eroare' );
}

function tc_booking_redirect( $back, $status ) {
	wp_safe_redirect( add_query_arg( 'tc_status', $status, $back ) . '#programare' );
	exit;
}
