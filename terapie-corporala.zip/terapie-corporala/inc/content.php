<?php
/**
 * Content types managed from wp-admin:
 * - Tratamente (price list, linked to the existing page of each treatment)
 * - Recenzii (patient reviews)
 * - Galerie (photos for the hero slider and the results section)
 * Seeded once with the clinic's current content on theme activation.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'tc_register_content' );
function tc_register_content() {
	register_post_type(
		'tratament',
		array(
			'labels'       => array(
				'name'          => __( 'Tratamente', 'tc' ),
				'singular_name' => __( 'Tratament', 'tc' ),
				'add_new_item'  => __( 'Adaugă tratament', 'tc' ),
				'edit_item'     => __( 'Editează tratament', 'tc' ),
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => false,
			'menu_icon'    => 'dashicons-heart',
			'supports'     => array( 'title', 'page-attributes' ),
		)
	);
	register_taxonomy(
		'problema',
		'tratament',
		array(
			'labels'            => array(
				'name'          => __( 'Probleme (Ce vă doare?)', 'tc' ),
				'singular_name' => __( 'Problemă', 'tc' ),
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
		)
	);

	register_post_type(
		'recenzie',
		array(
			'labels'       => array(
				'name'          => __( 'Recenzii', 'tc' ),
				'singular_name' => __( 'Recenzie', 'tc' ),
				'add_new_item'  => __( 'Adaugă recenzie', 'tc' ),
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => false,
			'menu_icon'    => 'dashicons-format-quote',
			'supports'     => array( 'title', 'editor', 'page-attributes' ),
		)
	);

	register_post_type(
		'fotografie',
		array(
			'labels'       => array(
				'name'          => __( 'Galerie', 'tc' ),
				'singular_name' => __( 'Fotografie', 'tc' ),
				'add_new_item'  => __( 'Adaugă fotografie', 'tc' ),
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => false,
			'menu_icon'    => 'dashicons-format-gallery',
			'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
		)
	);
	register_taxonomy(
		'album',
		'fotografie',
		array(
			'labels'            => array(
				'name'          => __( 'Unde apare', 'tc' ),
				'singular_name' => __( 'Secțiune', 'tc' ),
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => false,
			'show_admin_column' => true,
			'hierarchical'      => true,
		)
	);
}

/* ---------- Meta boxes ---------- */

function tc_meta_fields() {
	return array(
		'tratament'  => array(
			'_tc_descriere'  => array( 'label' => __( 'Descriere scurtă', 'tc' ), 'type' => 'text' ),
			'_tc_pret'       => array( 'label' => __( 'Preț (lei) — 0 = „la cerere”', 'tc' ), 'type' => 'number' ),
			'_tc_durata'     => array( 'label' => __( 'Durată (ex: 30 min)', 'tc' ), 'type' => 'text' ),
			'_tc_pagina'     => array( 'label' => __( 'Pagina cu detalii', 'tc' ), 'type' => 'page' ),
			'_tc_evidentiat' => array( 'label' => __( 'Apare la „Aparatura”', 'tc' ), 'type' => 'checkbox' ),
		),
		'recenzie'   => array(
			'_tc_context' => array( 'label' => __( 'Context (ex: dureri lombare)', 'tc' ), 'type' => 'text' ),
			'_tc_stele'   => array( 'label' => __( 'Stele (1–5)', 'tc' ), 'type' => 'number' ),
		),
		'fotografie' => array(
			'_tc_img_url' => array( 'label' => __( 'Adresa imaginii (dacă nu setați „Imagine reprezentativă”)', 'tc' ), 'type' => 'url' ),
		),
	);
}

add_action( 'add_meta_boxes', 'tc_add_meta_boxes' );
function tc_add_meta_boxes() {
	foreach ( array_keys( tc_meta_fields() ) as $type ) {
		add_meta_box( 'tc_details', __( 'Detalii', 'tc' ), 'tc_render_meta_box', $type, 'normal', 'high' );
	}
}

function tc_render_meta_box( $post ) {
	$fields = tc_meta_fields()[ $post->post_type ];
	wp_nonce_field( 'tc_save_meta', 'tc_meta_nonce' );
	echo '<table class="form-table" role="presentation">';
	foreach ( $fields as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		printf( '<tr><th><label for="%1$s">%2$s</label></th><td>', esc_attr( $key ), esc_html( $field['label'] ) );
		switch ( $field['type'] ) {
			case 'page':
				wp_dropdown_pages(
					array(
						'name'              => esc_attr( $key ),
						'id'                => esc_attr( $key ),
						'selected'          => absint( $value ),
						'show_option_none'  => esc_html__( '— fără pagină —', 'tc' ),
						'option_none_value' => '0',
					)
				);
				break;
			case 'checkbox':
				printf( '<input type="checkbox" id="%1$s" name="%1$s" value="1" %2$s>', esc_attr( $key ), checked( $value, '1', false ) );
				break;
			default:
				printf(
					'<input type="%3$s" id="%1$s" name="%1$s" value="%2$s" class="regular-text" %4$s>',
					esc_attr( $key ),
					esc_attr( $value ),
					esc_attr( $field['type'] ),
					'number' === $field['type'] ? 'min="0" step="1"' : ''
				);
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

add_action( 'save_post', 'tc_save_meta', 10, 2 );
function tc_save_meta( $post_id, $post ) {
	$all = tc_meta_fields();
	if ( ! isset( $all[ $post->post_type ] ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	$nonce = isset( $_POST['tc_meta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['tc_meta_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'tc_save_meta' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( $all[ $post->post_type ] as $key => $field ) {
		if ( 'checkbox' === $field['type'] ) {
			update_post_meta( $post_id, $key, empty( $_POST[ $key ] ) ? '0' : '1' );
			continue;
		}
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( 'number' === $field['type'] || 'page' === $field['type'] ) {
			$value = absint( $raw );
		} elseif ( 'url' === $field['type'] ) {
			$value = esc_url_raw( $raw );
		} else {
			$value = sanitize_text_field( $raw );
		}
		if ( '_tc_stele' === $key ) {
			$value = max( 1, min( 5, $value ) );
		}
		update_post_meta( $post_id, $key, $value );
	}
}

/* Admin lists follow the site order (the "Order" field) unless a column is sorted. */
add_action( 'pre_get_posts', 'tc_admin_list_order' );
function tc_admin_list_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() || $query->get( 'orderby' ) ) {
		return;
	}
	if ( in_array( $query->get( 'post_type' ), array( 'tratament', 'recenzie', 'fotografie' ), true ) ) {
		$query->set( 'orderby', array( 'menu_order' => 'ASC', 'title' => 'ASC' ) );
	}
}

add_filter( 'manage_tratament_posts_columns', 'tc_tratament_columns' );
function tc_tratament_columns( $cols ) {
	$cols['tc_pret']   = __( 'Preț', 'tc' );
	$cols['tc_durata'] = __( 'Durată', 'tc' );
	return $cols;
}

add_action( 'manage_tratament_posts_custom_column', 'tc_tratament_column_value', 10, 2 );
function tc_tratament_column_value( $col, $post_id ) {
	if ( 'tc_pret' === $col ) {
		echo esc_html( tc_price_label( $post_id ) );
	} elseif ( 'tc_durata' === $col ) {
		echo esc_html( get_post_meta( $post_id, '_tc_durata', true ) );
	}
}

/* ---------- Front-end helpers ---------- */

function tc_price_label( $post_id ) {
	$price = absint( get_post_meta( $post_id, '_tc_pret', true ) );
	return $price ? $price . ' lei' : __( 'Preț la cerere', 'tc' );
}

function tc_treatment_link( $post_id ) {
	$page = absint( get_post_meta( $post_id, '_tc_pagina', true ) );
	return ( $page && 'publish' === get_post_status( $page ) ) ? get_permalink( $page ) : '';
}

/**
 * Photo URL: featured image if set, otherwise the stored image address.
 */
function tc_photo_url( $post_id, $size = 'large' ) {
	$url = get_the_post_thumbnail_url( $post_id, $size );
	return $url ? $url : (string) get_post_meta( $post_id, '_tc_img_url', true );
}

function tc_photos( $album, $limit = 12 ) {
	$photos = get_posts(
		array(
			'post_type'      => 'fotografie',
			'posts_per_page' => $limit,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => 'album',
					'field'    => 'slug',
					'terms'    => $album,
				),
			),
		)
	);
	// Skip entries that have neither a featured image nor an image address.
	return array_values( array_filter( $photos, static function ( $p ) { return '' !== tc_photo_url( $p->ID ); } ) );
}

/**
 * Treatment linked to a given page (for the price box on treatment pages).
 */
function tc_treatment_for_page( $page_id ) {
	$found = get_posts(
		array(
			'post_type'      => 'tratament',
			'posts_per_page' => 1,
			'meta_key'       => '_tc_pagina', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => absint( $page_id ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	return $found ? $found[0] : null;
}

/* ---------- One-time seed with the clinic's current content ---------- */

// Runs on activation and, as a fallback (activation via WP-CLI or a host panel
// does not always fire the hook with the theme loaded), on the first admin page load.
add_action( 'after_switch_theme', 'tc_seed_content' );
add_action( 'admin_init', 'tc_seed_content' );
function tc_seed_content() {
	// Only an administrator's real page load seeds (admin_init also fires on
	// admin-post.php, which the public booking form uses, and on AJAX).
	if ( get_option( 'tc_seeded' ) || ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
		return;
	}
	// Validate the data before claiming the seed, so a broken file can be retried.
	$data = json_decode( (string) file_get_contents( TC_DIR . '/inc/seed.json' ), true );
	if ( ! is_array( $data ) || ! isset( $data['probleme'], $data['tratamente'], $data['recenzii'], $data['fotografii'] ) ) {
		return;
	}
	// add_option() is atomic: only the first request gets true, so the seed never runs twice.
	if ( ! add_option( 'tc_seeded', 1, '', 'yes' ) ) {
		return;
	}

	foreach ( $data['probleme'] as $p ) {
		if ( ! term_exists( $p['slug'], 'problema' ) ) {
			wp_insert_term( $p['nume'], 'problema', array( 'slug' => $p['slug'], 'description' => $p['descriere'] ) );
		}
	}
	foreach ( array( 'prima-pagina' => 'Prima pagină (galerie)', 'rezultate' => 'Rezultate' ) as $slug => $name ) {
		if ( ! term_exists( $slug, 'album' ) ) {
			wp_insert_term( $name, 'album', array( 'slug' => $slug ) );
		}
	}

	foreach ( $data['tratamente'] as $i => $t ) {
		$page = get_page_by_path( $t['pagina'] );
		$id   = wp_insert_post(
			array(
				'post_type'   => 'tratament',
				'post_status' => 'publish',
				'post_title'  => $t['nume'],
				'menu_order'  => $i,
				'meta_input'  => array(
					'_tc_descriere'  => $t['descriere'],
					'_tc_durata'     => $t['durata'],
					'_tc_pret'       => (int) $t['pret'],
					'_tc_pagina'     => $page ? $page->ID : 0,
					'_tc_evidentiat' => $t['evidentiat'] ? '1' : '0',
				),
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			wp_set_object_terms( $id, $t['probleme'], 'problema' );
		}
	}

	foreach ( $data['recenzii'] as $i => $r ) {
		wp_insert_post(
			array(
				'post_type'    => 'recenzie',
				'post_status'  => 'publish',
				'post_title'   => $r['nume'],
				'post_content' => $r['text'],
				'menu_order'   => $i,
				'meta_input'   => array(
					'_tc_context' => $r['context'],
					'_tc_stele'   => 5,
				),
			)
		);
	}

	foreach ( $data['fotografii'] as $i => $f ) {
		$id = wp_insert_post(
			array(
				'post_type'   => 'fotografie',
				'post_status' => 'publish',
				'post_title'  => $f['titlu'],
				'menu_order'  => $i,
				'meta_input'  => array( '_tc_img_url' => esc_url_raw( $f['url'] ) ),
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			wp_set_object_terms( $id, $f['album'], 'album' );
		}
	}
}

/**
 * Creates the "Acasă" page from the theme's section patterns (once, with its own
 * flag, so sites seeded by an older version also get it) and makes it the front
 * page. The previous front-page setting is restored when the theme is switched off.
 */
add_action( 'after_switch_theme', 'tc_seed_home_page', 20 );
add_action( 'admin_init', 'tc_seed_home_page', 20 );
function tc_seed_home_page() {
	if ( get_option( 'tc_home_seeded' ) || ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
		return;
	}
	if ( ! add_option( 'tc_home_seeded', 1, '', 'yes' ) ) {
		return;
	}

	// Re-use the page created on an earlier activation instead of making a duplicate.
	$existing = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => '_tc_home_page', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'         => 'ids',
		)
	);
	$id = $existing ? (int) $existing[0] : tc_create_home_page();
	if ( ! $id ) {
		return;
	}
	update_option( 'tc_previous_front', array( get_option( 'show_on_front' ), (int) get_option( 'page_on_front' ) ), false );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $id );
}

/* Switching to another theme puts back the front page the site had before. */
add_action( 'switch_theme', 'tc_restore_front_page' );
function tc_restore_front_page() {
	$previous = get_option( 'tc_previous_front' );
	if ( is_array( $previous ) && 2 === count( $previous ) ) {
		update_option( 'show_on_front', $previous[0] ? $previous[0] : 'posts' );
		update_option( 'page_on_front', (int) $previous[1] );
	}
	delete_option( 'tc_previous_front' );
	delete_option( 'tc_home_seeded' );
}

/* Without a static front page, use the normal templates instead of an empty front-page. */
add_filter( 'frontpage_template_hierarchy', 'tc_frontpage_only_when_static' );
function tc_frontpage_only_when_static( $templates ) {
	return 'page' === get_option( 'show_on_front' ) && get_option( 'page_on_front' ) ? $templates : array();
}

function tc_create_home_page() {
	$sections = array( 'hero', 'despre', 'tratamente', 'aparatura', 'rezultate', 'recenzii', 'locatie', 'programare' );
	$content  = '';
	foreach ( $sections as $slug ) {
		$file = TC_DIR . '/patterns/' . $slug . '.php';
		if ( ! file_exists( $file ) ) {
			continue;
		}
		ob_start();
		include $file;
		$content .= trim( ob_get_clean() ) . "\n\n";
	}
	if ( '' === $content ) {
		return 0;
	}
	$id = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'Acasă',
			'post_name'    => 'acasa',
			'post_content' => wp_slash( $content ),
			'meta_input'   => array( '_tc_home_page' => '1' ),
		)
	);
	return ( $id && ! is_wp_error( $id ) ) ? (int) $id : 0;
}
