<?php
/**
 * Theme blocks ("Terapie Corporală" category in the inserter).
 *
 * - tc/zona-widget: shows a classic widget area (Appearance → Widgets) inside
 *   the block templates, so the site keeps the old sidebar widgets.
 * - tc/contact: phone, WhatsApp, address and hours from Settings → Date cabinet.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

const TC_WIDGET_AREAS = array( 'sidebar-1', 'sidebar-2', 'sidebar-3' );

add_filter( 'block_categories_all', 'tc_block_category' );
function tc_block_category( $categories ) {
	array_unshift( $categories, array( 'slug' => 'terapie-corporala', 'title' => 'Terapie Corporală' ) );
	return $categories;
}

add_action( 'init', 'tc_register_blocks' );
function tc_register_blocks() {
	wp_register_script(
		'tc-blocks-editor',
		TC_URI . '/assets/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor', 'wp-components' ),
		TC_VERSION,
		true
	);

	$blocks = array(
		'zona-widget' => array( 'Zonă de widgeturi', 'welcome-widgets-menus', array( 'zona' => array( 'type' => 'string', 'default' => 'sidebar-1' ) ) ),
		'contact'     => array( 'Date de contact', 'phone', array( 'variant' => array( 'type' => 'string', 'default' => 'lista' ) ) ),
		'unde-ne-gasesti' => array( 'Unde ne găsești (adresă, program, hartă)', 'location-alt', array( 'titlu' => array( 'type' => 'string', 'default' => 'Unde ne găsești' ) ) ),
		'anunt'           => array( 'Anunț important (din Setări → Date cabinet)', 'megaphone', array() ),
	);

	foreach ( $blocks as $slug => $def ) {
		register_block_type(
			'tc/' . $slug,
			array(
				'api_version'           => 3,
				'title'                 => $def[0],
				'category'              => 'terapie-corporala',
				'icon'                  => $def[1],
				'attributes'            => $def[2],
				'supports'              => array(
					'html'      => false,
					'anchor'    => true,
					'className' => true,
				),
				'editor_script_handles' => array( 'tc-blocks-editor' ),
				'render_callback'       => 'tc_render_' . str_replace( '-', '_', $slug ),
			)
		);
	}
}

/**
 * Wrapper attributes (custom class, anchor) for a dynamic block.
 */
function tc_wrap( $class ) {
	return get_block_wrapper_attributes( array( 'class' => $class ) );
}

/**
 * In the editor preview only: explain what an empty block will show.
 */
function tc_editor_note( $text ) {
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return '<p class="tc-placeholder">' . esc_html( $text ) . '</p>';
	}
	return '';
}

/* ---------- Widget area ---------- */

function tc_render_zona_widget( $attributes ) {
	$zona = isset( $attributes['zona'] ) && in_array( $attributes['zona'], TC_WIDGET_AREAS, true ) ? $attributes['zona'] : 'sidebar-1';

	if ( is_active_sidebar( $zona ) ) {
		ob_start();
		dynamic_sidebar( $zona );
		return '<div ' . tc_wrap( 'widget-area widget-area-' . $zona ) . '>' . ob_get_clean() . '</div>';
	}

	// A fresh install has no widgets yet: the sidebar still lists every page, like the old site.
	if ( 'sidebar-1' === $zona ) {
		$pages = wp_list_pages(
			array(
				'title_li' => '',
				'echo'     => false,
			)
		);
		return '<div ' . tc_wrap( 'widget-area widget-area-sidebar-1' ) . '><section class="widget widget_pages"><h2 class="widget-title">'
			. esc_html__( 'Pagini', 'tc' ) . '</h2><nav aria-label="' . esc_attr__( 'Pagini', 'tc' ) . '"><ul>' . $pages . '</ul></nav></section></div>';
	}

	global $wp_registered_sidebars;
	$name = isset( $wp_registered_sidebars[ $zona ] ) ? $wp_registered_sidebars[ $zona ]['name'] : $zona;
	/* translators: %s: widget area name. */
	return tc_editor_note( sprintf( __( 'Zona „%s” nu are widgeturi. Se adaugă din Aspect → Widgeturi.', 'tc' ), $name ) );
}

/* ---------- Contact ---------- */

function tc_render_contact( $attributes ) {
	$variant = isset( $attributes['variant'] ) && 'subsol' === $attributes['variant'] ? 'subsol' : 'lista';
	$wa      = tc_wa_href();
	ob_start();
	?>
	<ul <?php echo tc_wrap( 'subsol' === $variant ? 'contact-list foot-contact' : 'contact-list' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<li><?php echo tc_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo esc_html( tc_opt( 'telefon' ) ); ?></a></li>
		<?php if ( $wa ) : ?>
			<li><?php echo tc_icon( 'wa' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo esc_html( tc_opt( 'text_whatsapp' ) ); ?></a></li>
		<?php endif; ?>
		<li><?php echo tc_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_url( tc_opt( 'harta_url' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( tc_opt( 'adresa' ) ); ?><?php echo tc_opt( 'zona' ) ? ' · ' . esc_html( tc_opt( 'zona' ) ) : ''; ?></a></li>
		<li><?php echo tc_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( implode( ' · ', array_map( 'tc_program_line', tc_program_rows() ) ) ); ?></span></li>
	</ul>
	<?php
	return ob_get_clean();
}

function tc_program_line( $row ) {
	return $row[1] ? $row[0] . ': ' . $row[1] : $row[0];
}

/* ---------- "Unde ne găsești": address, hours, phone, directions, map ---------- */

function tc_render_unde_ne_gasesti( $attributes ) {
	$title = isset( $attributes['titlu'] ) && '' !== trim( $attributes['titlu'] ) ? $attributes['titlu'] : __( 'Unde ne găsești', 'tc' );
	$map   = tc_opt( 'harta_embed' );
	ob_start();
	?>
	<section <?php echo tc_wrap( 'locatie' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> aria-labelledby="locatie-titlu">
		<h2 class="locatie-titlu" id="locatie-titlu"><?php echo tc_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( $title ); ?></h2>
		<div class="locatie-grid">
			<div class="locatie-info">
				<div class="locatie-rand">
					<p class="locatie-eticheta"><?php echo esc_html( tc_opt( 'eticheta_adresa' ) ); ?></p>
					<p class="locatie-adresa"><?php echo esc_html( tc_opt( 'adresa' ) ); ?></p>
					<?php if ( tc_opt( 'zona' ) ) : ?>
						<p class="locatie-reper"><?php echo esc_html( tc_opt( 'zona' ) ); ?></p>
					<?php endif; ?>
				</div>
				<div class="locatie-rand">
					<p class="locatie-eticheta"><?php echo esc_html( tc_opt( 'eticheta_program' ) ); ?></p>
					<dl class="locatie-program">
						<?php foreach ( tc_program_rows() as $row ) : ?>
							<div><dt><?php echo esc_html( $row[0] ); ?></dt><?php if ( $row[1] ) : ?><dd><?php echo esc_html( $row[1] ); ?></dd><?php endif; ?></div>
						<?php endforeach; ?>
					</dl>
				</div>
				<div class="locatie-rand">
					<p class="locatie-eticheta"><?php echo esc_html( tc_opt( 'eticheta_telefon' ) ); ?></p>
					<p class="locatie-telefon"><a href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo esc_html( tc_opt( 'telefon' ) ); ?></a></p>
				</div>
				<div class="locatie-butoane">
					<a class="locatie-btn locatie-btn-ruta" href="<?php echo esc_url( tc_opt( 'harta_url' ) ); ?>" target="_blank" rel="noopener"><?php echo tc_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'text_ruta' ) ); ?></a>
					<a class="locatie-btn locatie-btn-suna" href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo tc_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'text_suna' ) ); ?></a>
				</div>
			</div>
			<?php if ( $map ) : ?>
				<div class="locatie-harta">
					<iframe src="<?php echo esc_url( $map ); ?>" title="<?php echo esc_attr( sprintf( /* translators: %s: address */ __( 'Hartă: %s', 'tc' ), tc_opt( 'adresa' ) ) ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/* ---------- "Anunț important": highlighted box at the top of the page ---------- */

function tc_render_anunt() {
	$in_editor = defined( 'REST_REQUEST' ) && REST_REQUEST;
	if ( ! tc_opt_on( 'anunt_on' ) ) {
		return tc_editor_note( __( 'Anunțul este oprit (Setări → Date cabinet → Anunț important).', 'tc' ) );
	}
	if ( ! $in_editor && ! tc_opt_on( 'anunt_peste_tot' ) && ! is_front_page() ) {
		return '';
	}
	$rows = tc_anunt_rows();
	if ( ! $rows ) {
		return '';
	}
	ob_start();
	?>
	<aside <?php echo tc_wrap( 'anunt' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> aria-label="<?php echo esc_attr( tc_opt( 'anunt_titlu' ) ? tc_opt( 'anunt_titlu' ) : __( 'Anunț', 'tc' ) ); ?>">
		<span class="anunt-semn" aria-hidden="true">!</span>
		<div class="anunt-corp">
		<?php if ( tc_opt( 'anunt_titlu' ) ) : ?>
			<p class="anunt-titlu"><?php echo esc_html( tc_opt( 'anunt_titlu' ) ); ?></p>
		<?php endif; ?>
		<ul class="anunt-lista">
			<?php foreach ( $rows as $row ) : ?>
				<li><span class="anunt-text"><?php echo esc_html( $row[0] ); ?></span><?php if ( $row[1] ) : ?><strong class="anunt-pret"><?php echo esc_html( $row[1] ); ?></strong><?php endif; ?></li>
			<?php endforeach; ?>
		</ul>
		</div>
	</aside>
	<?php
	return ob_get_clean();
}
