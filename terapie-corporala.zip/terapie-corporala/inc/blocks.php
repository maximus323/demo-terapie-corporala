<?php
/**
 * Dynamic blocks ("Terapie Corporală" category in the inserter). Each renders
 * live data (treatments, reviews, photos, clinic details) and can be moved,
 * duplicated or removed anywhere in the editor.
 *
 * @package TerapieCorporala
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'block_categories_all', 'tc_block_category' );
function tc_block_category( $categories ) {
	array_unshift( $categories, array( 'slug' => 'terapie-corporala', 'title' => 'Terapie Corporală' ) );
	return $categories;
}

add_action( 'init', 'tc_register_blocks' );
function tc_register_blocks() {
	wp_register_script(
		'tc-blocks-editor',
		TC_URI . '/assets/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor', 'wp-components' ),
		TC_VERSION,
		true
	);

	$blocks = array(
		'contact'          => array( 'Date de contact', 'phone', array( 'variant' => array( 'type' => 'string', 'default' => 'lista' ) ) ),
		'galerie'          => array( 'Galerie foto', 'format-gallery', array(
			'album'  => array( 'type' => 'string', 'default' => 'prima-pagina' ),
			'layout' => array( 'type' => 'string', 'default' => 'hero' ),
		) ),
		'tratamente'       => array( 'Tratamente și prețuri', 'heart', array( 'filters' => array( 'type' => 'boolean', 'default' => true ) ) ),
		'aparatura'        => array( 'Aparatura (tratamente evidențiate)', 'star-filled', array() ),
		'recenzii'         => array( 'Recenzii', 'format-quote', array( 'initial' => array( 'type' => 'number', 'default' => 6 ) ) ),
		'programare'       => array( 'Formular de programare', 'calendar-alt', array() ),
		'pret'             => array( 'Preț tratament (pe pagina lui)', 'tag', array( 'variant' => array( 'type' => 'string', 'default' => 'box' ) ) ),
		'lista-tratamente' => array( 'Listă linkuri tratamente', 'list-view', array( 'count' => array( 'type' => 'number', 'default' => 8 ) ) ),
		'legal'            => array( 'Linkuri legale', 'shield', array() ),
		'harta'            => array( 'Hartă (Google Maps)', 'location', array(
			'direct' => array( 'type' => 'boolean', 'default' => false ),
			'zoom'   => array( 'type' => 'number', 'default' => 16 ),
		) ),
	);

	foreach ( $blocks as $slug => $def ) {
		register_block_type(
			'tc/' . $slug,
			array(
				'api_version'          => 3,
				'title'                => $def[0],
				'category'             => 'terapie-corporala',
				'icon'                 => $def[1],
				'attributes'           => $def[2],
				'uses_context'         => array( 'postId' ),
				'supports'             => array(
					'html'      => false,
					'anchor'    => true,
					'className' => true,
				),
				'editor_script_handles' => array( 'tc-blocks-editor' ),
				'render_callback'      => 'tc_render_' . str_replace( '-', '_', $slug ),
			)
		);
	}
}

/**
 * Wrapper attributes (custom class, anchor) for a dynamic block.
 */
function tc_wrap( $class ) {
	return get_block_wrapper_attributes( array( 'class' => $class ) );
}

/**
 * In the editor preview only: explain what an empty dynamic block will show.
 */
function tc_editor_note( $text ) {
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return '<p class="tc-placeholder">' . esc_html( $text ) . '</p>';
	}
	return '';
}

/* ---------- Contact ---------- */

function tc_render_contact( $attributes ) {
	$variant = isset( $attributes['variant'] ) ? $attributes['variant'] : 'lista';
	$wa      = tc_wa_href();
	ob_start();
	if ( 'bara' === $variant ) :
		?>
		<div <?php echo tc_wrap( 'topbar-in' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
			<a href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo tc_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'telefon' ) ); ?></a>
			<span><?php echo esc_html( tc_opt( 'bara_text' ) ); ?></span>
			<span><?php echo tc_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'program' ) ); ?></span>
		</div>
		<?php
	else :
		?>
		<ul <?php echo tc_wrap( 'subsol' === $variant ? 'foot-list foot-contact' : 'contact-list' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
			<li><?php echo tc_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo esc_html( tc_opt( 'telefon' ) ); ?></a></li>
			<?php if ( $wa ) : ?>
				<li><?php echo tc_icon( 'wa' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Scrieți-ne pe WhatsApp', 'tc' ); ?></a></li>
			<?php endif; ?>
			<li><?php echo tc_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="<?php echo esc_url( tc_opt( 'harta_url' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( tc_opt( 'adresa' ) ); ?><?php echo 'subsol' === $variant ? '' : ' · ' . esc_html( tc_opt( 'zona' ) ); ?></a></li>
			<li><?php echo tc_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( tc_opt( 'program' ) ); ?></span></li>
		</ul>
		<?php
	endif;
	return ob_get_clean();
}

/* ---------- Photo gallery (hero slider or grid) ---------- */

function tc_render_galerie( $attributes ) {
	$album  = isset( $attributes['album'] ) ? sanitize_key( $attributes['album'] ) : 'prima-pagina';
	$layout = isset( $attributes['layout'] ) && 'grid' === $attributes['layout'] ? 'grid' : 'hero';
	$photos = tc_photos( $album, 12 );
	if ( ! $photos ) {
		return tc_editor_note( __( 'Nu există fotografii în această secțiune. Adăugați-le din Galerie → Adaugă fotografie.', 'tc' ) );
	}
	ob_start();
	if ( 'hero' === $layout ) :
		?>
		<figure <?php echo tc_wrap( 'hero-gallery' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-gallery>
			<div class="hg-main">
				<img src="<?php echo esc_url( tc_photo_url( $photos[0]->ID ) ); ?>" alt="<?php echo esc_attr( get_the_title( $photos[0] ) ); ?>" data-gallery-main fetchpriority="high">
				<figcaption data-gallery-caption><?php echo esc_html( get_the_title( $photos[0] ) ); ?></figcaption>
			</div>
			<?php if ( count( $photos ) > 1 ) : ?>
				<div class="hg-thumbs" role="group" aria-label="<?php esc_attr_e( 'Fotografii', 'tc' ); ?>">
					<?php foreach ( array_slice( $photos, 0, 5 ) as $i => $photo ) : ?>
						<button type="button" class="hg-thumb" aria-pressed="<?php echo 0 === $i ? 'true' : 'false'; ?>" data-src="<?php echo esc_url( tc_photo_url( $photo->ID ) ); ?>" data-alt="<?php echo esc_attr( get_the_title( $photo ) ); ?>">
							<img src="<?php echo esc_url( tc_photo_url( $photo->ID, 'medium' ) ); ?>" alt="" loading="lazy">
							<span class="screen-reader-text"><?php echo esc_html( get_the_title( $photo ) ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</figure>
		<?php
	else :
		?>
		<div <?php echo tc_wrap( 'results-grid results-' . min( 3, count( $photos ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
			<?php foreach ( $photos as $photo ) : ?>
				<figure data-reveal>
					<img src="<?php echo esc_url( tc_photo_url( $photo->ID ) ); ?>" alt="<?php echo esc_attr( get_the_title( $photo ) ); ?>" loading="lazy">
					<figcaption><?php echo esc_html( get_the_title( $photo ) ); ?></figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
		<?php
	endif;
	return ob_get_clean();
}

/* ---------- Treatments with prices + filter ---------- */

function tc_render_tratamente( $attributes ) {
	$show_filters = ! isset( $attributes['filters'] ) || $attributes['filters'];
	$problems     = get_terms(
		array(
			'taxonomy'   => 'problema',
			'hide_empty' => true,
			'orderby'    => 'term_id',
		)
	);
	$problems   = is_wp_error( $problems ) ? array() : $problems;
	$treatments = get_posts(
		array(
			'post_type'      => 'tratament',
			'posts_per_page' => -1,
			'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		)
	);
	ob_start();
	?>
	<div <?php echo tc_wrap( 'treatments' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php if ( $show_filters && $problems ) : ?>
			<div class="filters" role="group" aria-label="<?php esc_attr_e( 'Ce vă doare?', 'tc' ); ?>">
				<button type="button" class="filter" data-cat="" aria-pressed="true"><?php esc_html_e( 'Toate', 'tc' ); ?></button>
				<?php foreach ( $problems as $term ) : ?>
					<button type="button" class="filter" data-cat="<?php echo esc_attr( $term->slug ); ?>" aria-pressed="false" title="<?php echo esc_attr( $term->description ); ?>"><?php echo esc_html( $term->name ); ?></button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<ul class="svc-grid">
			<?php
			foreach ( $treatments as $t ) :
				$terms = get_the_terms( $t->ID, 'problema' );
				$terms = ( $terms && ! is_wp_error( $terms ) ) ? $terms : array();
				$desc  = get_post_meta( $t->ID, '_tc_descriere', true );
				$dur   = get_post_meta( $t->ID, '_tc_durata', true );
				$link  = tc_treatment_link( $t->ID );
				?>
				<li class="svc-card" data-cats="<?php echo esc_attr( implode( ' ', wp_list_pluck( $terms, 'slug' ) ) ); ?>">
					<h3><?php echo esc_html( get_the_title( $t ) ); ?></h3>
					<p class="svc-price"><?php echo esc_html( tc_price_label( $t->ID ) ); ?><?php if ( $dur ) : ?> <span>· <?php echo esc_html( $dur ); ?></span><?php endif; ?></p>
					<?php if ( $desc ) : ?><p class="svc-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
					<?php if ( $terms ) : ?>
						<ul class="tags"><?php foreach ( $terms as $term ) : ?><li><?php echo esc_html( $term->name ); ?></li><?php endforeach; ?></ul>
					<?php endif; ?>
					<?php if ( $link ) : ?>
						<a class="link-arrow" href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Detalii', 'tc' ); ?><span class="screen-reader-text"> — <?php echo esc_html( get_the_title( $t ) ); ?></span><?php echo tc_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php
	return ob_get_clean();
}

/* ---------- Featured treatments ---------- */

function tc_render_aparatura() {
	$featured = get_posts(
		array(
			'post_type'      => 'tratament',
			'posts_per_page' => 8,
			'orderby'        => array( 'menu_order' => 'ASC' ),
			'meta_key'       => '_tc_evidentiat', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	if ( ! $featured ) {
		return tc_editor_note( __( 'Bifați „Apare la Aparatura” la tratamentele care trebuie să apară aici.', 'tc' ) );
	}
	ob_start();
	?>
	<ul <?php echo tc_wrap( 'device-list' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php
		foreach ( $featured as $t ) :
			$link = tc_treatment_link( $t->ID );
			$desc = get_post_meta( $t->ID, '_tc_descriere', true );
			?>
			<li data-reveal>
				<a href="<?php echo esc_url( $link ? $link : home_url( '/#tratamente' ) ); ?>">
					<span class="dl-name"><?php echo esc_html( get_the_title( $t ) ); ?></span>
					<?php if ( $desc ) : ?><span class="dl-desc"><?php echo esc_html( $desc ); ?></span><?php endif; ?>
					<span class="dl-price"><?php echo esc_html( tc_price_label( $t->ID ) ); ?><?php echo tc_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
	return ob_get_clean();
}

/* ---------- Reviews ---------- */

function tc_render_recenzii( $attributes ) {
	$initial = isset( $attributes['initial'] ) ? max( 1, (int) $attributes['initial'] ) : 6;
	$reviews = get_posts(
		array(
			'post_type'      => 'recenzie',
			'posts_per_page' => 50,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		)
	);
	if ( ! $reviews ) {
		return tc_editor_note( __( 'Nu există recenzii. Adăugați-le din Recenzii → Adaugă recenzie.', 'tc' ) );
	}
	ob_start();
	?>
	<div <?php echo tc_wrap( 'reviews-block' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<ul class="rev-grid" aria-label="<?php esc_attr_e( 'Recenzii ale pacienților', 'tc' ); ?>">
			<?php
			foreach ( $reviews as $i => $review ) :
				$stars   = (int) get_post_meta( $review->ID, '_tc_stele', true );
				$context = get_post_meta( $review->ID, '_tc_context', true );
				?>
				<li class="rev-card<?php echo $i >= $initial ? ' rev-extra' : ''; ?>" data-reveal>
					<?php echo tc_stars( $stars ? $stars : 5 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<blockquote><p><?php echo esc_html( wp_strip_all_tags( $review->post_content ) ); ?></p></blockquote>
					<p class="rev-name"><?php echo esc_html( get_the_title( $review ) ); ?><?php if ( $context ) : ?><span><?php echo esc_html( $context ); ?></span><?php endif; ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( count( $reviews ) > $initial ) : ?>
			<button type="button" class="tc-btn tc-btn-line rev-all"><?php echo esc_html( sprintf( __( 'Vezi toate cele %d recenzii', 'tc' ), count( $reviews ) ) ); ?></button>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/* ---------- Booking form ---------- */

function tc_render_programare() {
	ob_start();
	tc_booking_form();
	return ob_get_clean();
}

/* ---------- Price of the treatment linked to the current page ---------- */

function tc_render_pret( $attributes, $content, $block ) {
	$page_id = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : get_queried_object_id();
	$t       = $page_id ? tc_treatment_for_page( $page_id ) : null;
	if ( ! $t ) {
		return tc_editor_note( __( 'Aici apare prețul, pe paginile alese ca „Pagina cu detalii” la un tratament.', 'tc' ) );
	}
	$dur = get_post_meta( $t->ID, '_tc_durata', true );
	ob_start();
	if ( isset( $attributes['variant'] ) && 'chips' === $attributes['variant'] ) :
		?>
		<p <?php echo tc_wrap( 'page-price' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>><span><?php echo esc_html( tc_price_label( $t->ID ) ); ?></span><?php if ( $dur ) : ?><span><?php echo esc_html( $dur ); ?></span><?php endif; ?></p>
		<?php
	else :
		?>
		<aside <?php echo tc_wrap( 'price-box' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> aria-label="<?php esc_attr_e( 'Preț și programare', 'tc' ); ?>">
			<p class="pb-label"><?php echo esc_html( get_the_title( $t ) ); ?></p>
			<p class="pb-price"><?php echo esc_html( tc_price_label( $t->ID ) ); ?></p>
			<?php if ( $dur ) : ?><p class="pb-dur"><?php echo esc_html( $dur ); ?> / <?php esc_html_e( 'ședință', 'tc' ); ?></p><?php endif; ?>
			<a class="tc-btn tc-btn-gold" href="<?php echo esc_url( home_url( '/#programare' ) ); ?>"><?php esc_html_e( 'Programează-te', 'tc' ); ?></a>
			<a class="tc-btn tc-btn-line" href="<?php echo esc_attr( tc_tel_href() ); ?>"><?php echo tc_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html( tc_opt( 'telefon' ) ); ?></a>
		</aside>
		<?php
	endif;
	return ob_get_clean();
}

/* ---------- Map of the clinic (address from Setări → Date cabinet) ---------- */

/**
 * By default the Google map loads only after the visitor clicks (no Google
 * cookies before consent). "direct" loads it immediately, e.g. when a cookie
 * plugin already handles consent.
 */
function tc_render_harta( $attributes ) {
	$address = tc_opt( 'adresa' );
	$zoom    = isset( $attributes['zoom'] ) ? max( 10, min( 20, (int) $attributes['zoom'] ) ) : 16;
	$src     = 'https://maps.google.com/maps?q=' . rawurlencode( $address ) . '&z=' . $zoom . '&output=embed';
	$title   = sprintf( __( 'Harta: %s', 'tc' ), $address );
	$direct  = ! empty( $attributes['direct'] );
	ob_start();
	?>
	<div <?php echo tc_wrap( 'map-box' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> data-map-src="<?php echo esc_url( $src ); ?>" data-map-title="<?php echo esc_attr( $title ); ?>">
		<?php if ( $direct ) : ?>
			<iframe src="<?php echo esc_url( $src ); ?>" title="<?php echo esc_attr( $title ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
		<?php else : ?>
			<div class="map-consent">
				<?php echo tc_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<p class="map-address"><?php echo esc_html( $address ); ?><span><?php echo esc_html( tc_opt( 'zona' ) ); ?></span></p>
				<button type="button" class="tc-btn tc-btn-gold map-load"><?php esc_html_e( 'Afișează harta', 'tc' ); ?></button>
				<p class="map-note"><?php esc_html_e( 'Harta este oferită de Google Maps și se încarcă doar după ce apăsați butonul.', 'tc' ); ?></p>
				<a class="map-link" href="<?php echo esc_url( tc_opt( 'harta_url' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Deschide în Google Maps', 'tc' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/* ---------- Footer lists ---------- */

function tc_render_lista_tratamente( $attributes ) {
	$count = isset( $attributes['count'] ) ? max( 1, (int) $attributes['count'] ) : 8;
	$items = get_posts(
		array(
			'post_type'      => 'tratament',
			'posts_per_page' => $count,
			'orderby'        => array( 'menu_order' => 'ASC' ),
		)
	);
	ob_start();
	?>
	<ul <?php echo tc_wrap( 'foot-list' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php
		foreach ( $items as $t ) :
			$link = tc_treatment_link( $t->ID );
			?>
			<li><a href="<?php echo esc_url( $link ? $link : home_url( '/#tratamente' ) ); ?>"><?php echo esc_html( get_the_title( $t ) ); ?></a></li>
		<?php endforeach; ?>
	</ul>
	<?php
	return ob_get_clean();
}

function tc_render_legal() {
	ob_start();
	?>
	<ul <?php echo tc_wrap( 'foot-list' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php if ( get_privacy_policy_url() ) : ?>
			<li><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Politica de confidențialitate', 'tc' ); ?></a></li>
		<?php endif; ?>
		<li><a href="https://anpc.ro/" target="_blank" rel="noopener">ANPC</a></li>
		<li><a href="https://anpc.ro/ce-este-sal/" target="_blank" rel="noopener"><?php esc_html_e( 'Soluționarea alternativă a litigiilor', 'tc' ); ?></a></li>
	</ul>
	<?php
	return ob_get_clean();
}
