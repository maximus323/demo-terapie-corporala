<?php
/**
 * Title: Tratamente și prețuri (cu filtru)
 * Slug: terapie-corporala/tratamente
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"tratamente","className":"services is-style-banda-inchisa"} -->
<section id="tratamente" class="wp-block-group services is-style-banda-inchisa"><!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap"><!-- wp:group {"className":"sec-head"} -->
<div class="wp-block-group sec-head"><!-- wp:heading -->
<h2 class="wp-block-heading">Tratamente și <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-color">prețuri.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Alegeți ce vă doare și vedeți tratamentele potrivite, cu durată și preț pe ședință.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:tc/tratamente /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
