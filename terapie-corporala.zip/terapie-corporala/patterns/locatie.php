<?php
/**
 * Title: De ce noi / Locație
 * Slug: terapie-corporala/locatie
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"locatie","className":"why"} -->
<section id="locatie" class="wp-block-group why"><!-- wp:group {"className":"wrap why-grid"} -->
<div class="wp-block-group wrap why-grid"><!-- wp:group {"className":"why-copy"} -->
<div class="wp-block-group why-copy"><!-- wp:heading -->
<h2 class="wp-block-heading">Fizioterapie în <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-ink-color">Sectorul 3.</mark></h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"reasons"} -->
<ol class="wp-block-list reasons"><!-- wp:list-item -->
<li><strong>Ușor de ajuns</strong><br>Pe Calea Călărașilor 137, lângă Hala Traian, cu transport în comun la câțiva pași.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Evaluare înainte de tratament</strong><br>Nu începem nicio procedură înainte să înțelegem cauza durerii și investigațiile pe care le aveți.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Prețuri afișate</strong><br>Prețul fiecărei ședințe este public, iar planul complet îl stabilim împreună de la început.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:paragraph {"className":"link-arrow"} -->
<p class="link-arrow"><a href="https://www.google.com/maps/search/?api=1&amp;query=Calea+Calarasilor+137+Bucuresti" target="_blank" rel="noreferrer noopener">Deschide în Google Maps</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:tc/harta {"zoom":16} /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
