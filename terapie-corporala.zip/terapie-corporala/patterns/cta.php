<?php
/**
 * Title: Bandă cu îndemn la programare
 * Slug: terapie-corporala/cta
 * Categories: terapie-corporala, call-to-action
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","className":"cta-band is-style-banda-inchisa"} -->
<section class="wp-block-group cta-band is-style-banda-inchisa"><!-- wp:group {"className":"wrap cta-in"} -->
<div class="wp-block-group wrap cta-in"><!-- wp:heading -->
<h2 class="wp-block-heading">Vreți să aflați dacă tratamentul vi se potrivește?</h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/#programare">Programați o evaluare</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-linie"} -->
<div class="wp-block-button is-style-linie"><a class="wp-block-button__link wp-element-button" href="tel:+40723428414">0723 428 414</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
