<?php
/**
 * Title: Ofertă + Despre cabinet
 * Slug: terapie-corporala/despre
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"aside","className":"offer"} -->
<aside class="wp-block-group offer"><!-- wp:group {"className":"wrap offer-in"} -->
<div class="wp-block-group wrap offer-in"><!-- wp:paragraph -->
<p><strong>Pachet tratament: 150 lei / ședință</strong> Toate procedurile necesare pentru afecțiunea dumneavoastră, într-o singură ședință.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-inchis"} -->
<div class="wp-block-button is-style-inchis"><a class="wp-block-button__link wp-element-button" href="#programare">Rezervă acum</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></aside>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"despre","className":"about"} -->
<section id="despre" class="wp-block-group about"><!-- wp:group {"className":"wrap about-grid"} -->
<div class="wp-block-group wrap about-grid"><!-- wp:image {"sizeSlug":"large","className":"about-pic"} -->
<figure class="wp-block-image size-large about-pic"><img src="https://www.terapiecorporala.ro/wp-content/uploads/2020/08/WhatsApp-Image-2020-08-26-at-16.28.00-2.jpeg" alt="Cabinetul Terapie Corporală"/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"about-copy"} -->
<div class="wp-block-group about-copy"><!-- wp:heading -->
<h2 class="wp-block-heading">Precizie și <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-ink-color">răbdare.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cabinetul Terapie Corporală tratează durerile de spate, de genunchi, de șold și de articulații cu aparatură modernă de fizioterapie, într-un spațiu liniștit din Sectorul 3.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fiecare pacient începe cu o evaluare: discutăm despre durere, istoric și investigațiile pe care le are deja, apoi alegem procedurile potrivite și numărul de ședințe.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"points"} -->
<ul class="wp-block-list points"><!-- wp:list-item -->
<li><strong>Aparatură modernă</strong><br>Laser rece, shockwave, TECAR, terahertz și rTMS.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Plan personalizat</strong><br>Procedurile se aleg după evaluare.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Același terapeut</strong><br>Fiecare ședință, făcută de Cătălin Franga.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Program prelungit</strong><br>Luni–vineri, până la 20:30.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph {"className":"link-arrow"} -->
<p class="link-arrow"><a href="/studii-terapie-laser/">Studii despre terapia laser</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
