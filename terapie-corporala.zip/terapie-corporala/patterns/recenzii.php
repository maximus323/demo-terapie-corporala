<?php
/**
 * Title: Recenzii pacienți
 * Slug: terapie-corporala/recenzii
 * Categories: terapie-corporala, testimonials
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"recenzii","className":"reviews is-style-banda-inchisa"} -->
<section id="recenzii" class="wp-block-group reviews is-style-banda-inchisa"><!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap"><!-- wp:group {"className":"sec-head sec-head-split"} -->
<div class="wp-block-group sec-head sec-head-split"><!-- wp:heading -->
<h2 class="wp-block-heading">Pacienți reali. <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-color">Cuvintele lor.</mark></h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"rating"} -->
<div class="wp-block-group rating"><!-- wp:paragraph {"className":"rating-value"} -->
<p class="rating-value">Excelent</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"rating-text"} -->
<p class="rating-text">10 recenzii pe Facebook</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:tc/recenzii {"initial":6} /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
