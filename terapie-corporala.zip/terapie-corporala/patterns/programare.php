<?php
/**
 * Title: Programare (contact + formular)
 * Slug: terapie-corporala/programare
 * Categories: terapie-corporala, call-to-action
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"programare","className":"booking-band"} -->
<section id="programare" class="wp-block-group booking-band"><!-- wp:image {"sizeSlug":"large","className":"booking-bg"} -->
<figure class="wp-block-image size-large booking-bg"><img src="https://www.terapiecorporala.ro/wp-content/uploads/2020/12/Tecar1@2x.jpg" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"wrap booking-grid"} -->
<div class="wp-block-group wrap booking-grid"><!-- wp:group {"className":"booking-copy"} -->
<div class="wp-block-group booking-copy"><!-- wp:heading -->
<h2 class="wp-block-heading">Primul pas: o evaluare.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Lăsați-ne numărul și vă sunăm pentru a stabili ora. Sau sunați direct.</p>
<!-- /wp:paragraph -->

<!-- wp:tc/contact {"variant":"lista"} /--></div>
<!-- /wp:group -->

<!-- wp:tc/programare /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
