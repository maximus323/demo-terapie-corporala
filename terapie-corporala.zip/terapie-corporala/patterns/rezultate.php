<?php
/**
 * Title: Rezultate (fotografii din Galerie)
 * Slug: terapie-corporala/rezultate
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"rezultate","className":"results"} -->
<section id="rezultate" class="wp-block-group results"><!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap"><!-- wp:group {"className":"sec-head"} -->
<div class="wp-block-group sec-head"><!-- wp:heading -->
<h2 class="wp-block-heading">Rezultate <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-ink-color">din cabinet.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Fotografii înainte și după tratament. Rezultatele diferă de la o persoană la alta.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:tc/galerie {"album":"rezultate","layout":"grid"} /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
