<?php
/**
 * Title: Prima secțiune (titlu, butoane, galerie, cifre)
 * Slug: terapie-corporala/hero
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","className":"hero"} -->
<section class="wp-block-group hero"><!-- wp:group {"className":"wrap hero-grid"} -->
<div class="wp-block-group wrap hero-grid"><!-- wp:group {"className":"hero-copy"} -->
<div class="wp-block-group hero-copy"><!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title">Grijă pentru <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-ink-color">fiecare mișcare.</mark></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lead"} -->
<p class="hero-lead">Cabinet de fizioterapie și terapia durerii în Sectorul 3, București: laser rece, shockwave, TECAR și terahertz pentru spate, genunchi și articulații.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"ctas"} -->
<div class="wp-block-buttons ctas"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#programare">Programează o evaluare</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-linie"} -->
<div class="wp-block-button is-style-linie"><a class="wp-block-button__link wp-element-button" href="#tratamente">Vezi tratamentele</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"className":"hero-meta"} -->
<p class="hero-meta">Calea Călărașilor 137, Sector 3, București · zona Hala Traian</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:tc/galerie {"album":"prima-pagina","layout":"hero"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"className":"figures"} -->
<div class="wp-block-group figures"><!-- wp:group {"className":"wrap figures-grid"} -->
<div class="wp-block-group wrap figures-grid"><!-- wp:group {"className":"figure"} -->
<div class="wp-block-group figure"><!-- wp:paragraph {"className":"fig-val"} -->
<p class="fig-val">10</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"fig-text"} -->
<p class="fig-text">recenzii excelente</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"figure"} -->
<div class="wp-block-group figure"><!-- wp:paragraph {"className":"fig-val"} -->
<p class="fig-val">22</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"fig-text"} -->
<p class="fig-text">tratamente disponibile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"figure"} -->
<div class="wp-block-group figure"><!-- wp:paragraph {"className":"fig-val"} -->
<p class="fig-val">150 lei</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"fig-text"} -->
<p class="fig-text">pachet complet pe ședință</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"figure"} -->
<div class="wp-block-group figure"><!-- wp:paragraph {"className":"fig-val"} -->
<p class="fig-val">20:30</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"fig-text"} -->
<p class="fig-text">deschis până seara, L–V</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
