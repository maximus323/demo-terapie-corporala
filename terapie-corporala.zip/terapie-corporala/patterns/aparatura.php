<?php
/**
 * Title: Aparatura (tratamente evidențiate + imagine)
 * Slug: terapie-corporala/aparatura
 * Categories: terapie-corporala
 * Viewport Width: 1440
 *
 * @package TerapieCorporala
 */
?>
<!-- wp:group {"tagName":"section","anchor":"aparatura","className":"devices"} -->
<section id="aparatura" class="wp-block-group devices"><!-- wp:group {"className":"wrap devices-grid"} -->
<div class="wp-block-group wrap devices-grid"><!-- wp:group {"className":"devices-copy"} -->
<div class="wp-block-group devices-copy"><!-- wp:heading -->
<h2 class="wp-block-heading">Aparatura face <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-gold-ink-color">diferența.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"lead"} -->
<p class="lead">Lucrăm cu aparate dedicate fiecărui tip de durere. Aici apar tratamentele bifate cu „Apare la Aparatura”, cu link spre pagina lor.</p>
<!-- /wp:paragraph -->

<!-- wp:tc/aparatura /--></div>
<!-- /wp:group -->

<!-- wp:image {"sizeSlug":"large","className":"devices-pic"} -->
<figure class="wp-block-image size-large devices-pic"><img src="https://www.terapiecorporala.ro/wp-content/uploads/2020/08/WhatsApp-Image-2020-08-26-at-16.27.59-1.jpeg" alt="Aparatură de fizioterapie din cabinet"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
