/* Editor side of the theme's dynamic blocks: live preview + settings in the sidebar. No build step. */
(function (wp) {
  var el = wp.element.createElement;
  var SSR = wp.serverSideRender;
  var useBlockProps = wp.blockEditor.useBlockProps;
  var Inspector = wp.blockEditor.InspectorControls;
  var C = wp.components;
  var none = function () { return null; };

  function Preview(props) {
    return el('div', useBlockProps(), el(SSR, { block: props.name, attributes: props.attributes }));
  }

  function withPanel(controls) {
    return function (props) {
      return el(
        wp.element.Fragment,
        null,
        el(Inspector, null, el(C.PanelBody, { title: 'Setări' }, controls(props))),
        el(Preview, props)
      );
    };
  }

  ['aparatura', 'programare', 'legal'].forEach(function (slug) {
    wp.blocks.registerBlockType('tc/' + slug, { edit: Preview, save: none });
  });

  wp.blocks.registerBlockType('tc/contact', {
    edit: withPanel(function (p) {
      return el(C.SelectControl, {
        label: 'Afișare',
        value: p.attributes.variant,
        options: [
          { label: 'Listă (telefon, WhatsApp, adresă, program)', value: 'lista' },
          { label: 'Bara de sus', value: 'bara' },
          { label: 'Subsol', value: 'subsol' }
        ],
        onChange: function (v) { p.setAttributes({ variant: v }); }
      });
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/galerie', {
    edit: withPanel(function (p) {
      return [
        el(C.TextControl, {
          key: 'album',
          label: 'Secțiunea din Galerie (slug)',
          help: 'Ex.: prima-pagina sau rezultate. Se alege la fiecare fotografie, în „Unde apare”.',
          value: p.attributes.album,
          onChange: function (v) { p.setAttributes({ album: v }); }
        }),
        el(C.SelectControl, {
          key: 'layout',
          label: 'Aspect',
          value: p.attributes.layout,
          options: [
            { label: 'Fotografie mare + miniaturi', value: 'hero' },
            { label: 'Grilă cu titluri', value: 'grid' }
          ],
          onChange: function (v) { p.setAttributes({ layout: v }); }
        })
      ];
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/tratamente', {
    edit: withPanel(function (p) {
      return el(C.ToggleControl, {
        label: 'Butoane „Ce vă doare?”',
        checked: !!p.attributes.filters,
        onChange: function (v) { p.setAttributes({ filters: v }); }
      });
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/recenzii', {
    edit: withPanel(function (p) {
      return el(C.RangeControl, {
        label: 'Recenzii afișate înainte de „Vezi toate”',
        min: 1, max: 30,
        value: p.attributes.initial,
        onChange: function (v) { p.setAttributes({ initial: v }); }
      });
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/pret', {
    edit: withPanel(function (p) {
      return el(C.SelectControl, {
        label: 'Afișare',
        value: p.attributes.variant,
        options: [
          { label: 'Casetă cu butoane', value: 'box' },
          { label: 'Etichete sub titlu', value: 'chips' }
        ],
        onChange: function (v) { p.setAttributes({ variant: v }); }
      });
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/harta', {
    edit: withPanel(function (p) {
      return [
        el(C.ToggleControl, {
          key: 'direct',
          label: 'Încarcă harta direct (fără buton)',
          help: 'Lăsați dezactivat dacă nu aveți un plugin de cookie-uri: harta Google se încarcă doar după click.',
          checked: !!p.attributes.direct,
          onChange: function (v) { p.setAttributes({ direct: v }); }
        }),
        el(C.RangeControl, {
          key: 'zoom',
          label: 'Zoom',
          min: 10, max: 20,
          value: p.attributes.zoom,
          onChange: function (v) { p.setAttributes({ zoom: v }); }
        })
      ];
    }),
    save: none
  });

  wp.blocks.registerBlockType('tc/lista-tratamente', {
    edit: withPanel(function (p) {
      return el(C.RangeControl, {
        label: 'Număr de tratamente',
        min: 1, max: 30,
        value: p.attributes.count,
        onChange: function (v) { p.setAttributes({ count: v }); }
      });
    }),
    save: none
  });
})(window.wp);
