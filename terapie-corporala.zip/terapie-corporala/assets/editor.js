/* Editor side of the theme blocks: live preview + settings in the sidebar. No build step. */
(function (wp) {
  var el = wp.element.createElement;
  var SSR = wp.serverSideRender;
  var useBlockProps = wp.blockEditor.useBlockProps;
  var Inspector = wp.blockEditor.InspectorControls;
  var C = wp.components;
  var none = function () { return null; };

  function select(label, attr, options) {
    return function (props) {
      return el(
        wp.element.Fragment,
        null,
        el(Inspector, null, el(C.PanelBody, { title: 'Setări' }, el(C.SelectControl, {
          label: label,
          value: props.attributes[attr],
          options: options,
          onChange: function (v) { var a = {}; a[attr] = v; props.setAttributes(a); }
        }))),
        el('div', useBlockProps(), el(SSR, { block: props.name, attributes: props.attributes }))
      );
    };
  }

  wp.blocks.registerBlockType('tc/zona-widget', {
    edit: select('Zona de widgeturi', 'zona', [
      { label: 'Bară laterală', value: 'sidebar-1' },
      { label: 'Sub conținut 1', value: 'sidebar-2' },
      { label: 'Sub conținut 2', value: 'sidebar-3' }
    ]),
    save: none
  });

  wp.blocks.registerBlockType('tc/contact', {
    edit: select('Afișare', 'variant', [
      { label: 'Listă', value: 'lista' },
      { label: 'Subsol (fundal închis)', value: 'subsol' }
    ]),
    save: none
  });
  wp.blocks.registerBlockType('tc/unde-ne-gasesti', {
    edit: function (props) {
      return el(
        wp.element.Fragment,
        null,
        el(Inspector, null, el(C.PanelBody, { title: 'Setări' },
          el(C.TextControl, { label: 'Titlu', value: props.attributes.titlu, onChange: function (v) { props.setAttributes({ titlu: v }); } }),
          el('p', null, 'Adresa, programul, telefonul și harta se modifică în Setări → Date cabinet.')
        )),
        el('div', useBlockProps(), el(SSR, { block: props.name, attributes: props.attributes }))
      );
    },
    save: none
  });
})(window.wp);
