/* Terapie Corporală — progressive enhancement. Without JS every section stays usable. */
(() => {
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Mobile navigation */
  const toggle = document.querySelector('.nav-toggle');
  if (toggle) {
    const header = toggle.closest('.site-header');
    const setOpen = (open) => {
      header.classList.toggle('nav-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    };
    toggle.addEventListener('click', () => setOpen(toggle.getAttribute('aria-expanded') !== 'true'));
    $$('.menu a', header).forEach((a) => a.addEventListener('click', () => setOpen(false)));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
  }

  /* "Ce vă doare?" filter */
  const filters = $$('.filter');
  const cards = $$('.svc-card[data-cats]');
  if (filters.length && cards.length) {
    const show = (cat) => {
      cards.forEach((c) => { c.hidden = cat !== '' && !c.dataset.cats.split(' ').includes(cat); });
      filters.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.cat === cat)));
    };
    filters.forEach((b) => b.addEventListener('click', () => show(b.dataset.cat)));
  }

  /* Hero gallery: thumbnails swap the large photo */
  $$('[data-gallery]').forEach((gallery) => {
    const main = gallery.querySelector('[data-gallery-main]');
    const caption = gallery.querySelector('[data-gallery-caption]');
    const thumbs = $$('.hg-thumb', gallery);
    thumbs.forEach((thumb) => thumb.addEventListener('click', () => {
      if (thumb.getAttribute('aria-pressed') === 'true') return;
      thumbs.forEach((t) => t.setAttribute('aria-pressed', String(t === thumb)));
      const swap = () => {
        main.src = thumb.dataset.src;
        main.alt = thumb.dataset.alt;
        if (caption) caption.textContent = thumb.dataset.alt;
        main.classList.remove('swapping');
      };
      if (reduceMotion) { swap(); return; }
      main.classList.add('swapping');
      setTimeout(swap, 220);
    }));
  });

  /* Reviews: long texts collapse with "Citește tot"; extra reviews behind one button */
  const grid = document.querySelector('.rev-grid');
  if (grid) {
    // Measured only while visible: hidden extra reviews are clamped after "Vezi toate".
    const clampCard = (card) => {
      if (card.querySelector('.rev-more')) return;
      const p = card.querySelector('blockquote p');
      card.classList.add('clamp');
      if (p.scrollHeight <= p.clientHeight + 2) { card.classList.remove('clamp'); return; }
      const more = document.createElement('button');
      more.type = 'button';
      more.className = 'rev-more';
      more.textContent = 'Citește tot';
      more.setAttribute('aria-expanded', 'false');
      more.addEventListener('click', () => {
        const open = card.classList.toggle('clamp') === false;
        more.textContent = open ? 'Mai puțin' : 'Citește tot';
        more.setAttribute('aria-expanded', String(open));
      });
      card.querySelector('blockquote').after(more);
    };
    $$('.rev-card:not(.rev-extra)', grid).forEach(clampCard);
    const showAll = document.querySelector('.rev-all');
    if (showAll) {
      showAll.addEventListener('click', () => {
        grid.classList.add('all');
        $$('.rev-extra', grid).forEach((c) => { c.classList.add('in'); clampCard(c); });
        showAll.hidden = true;
      });
    } else {
      $$('.rev-extra', grid).forEach(clampCard);
    }
  }

  /* Map: the Google iframe is created only after the visitor asks for it */
  $$('.map-load').forEach((btn) => btn.addEventListener('click', () => {
    const box = btn.closest('.map-box');
    const frame = document.createElement('iframe');
    frame.src = box.dataset.mapSrc;
    frame.title = box.dataset.mapTitle;
    frame.loading = 'lazy';
    frame.referrerPolicy = 'no-referrer-when-downgrade';
    frame.allowFullscreen = true;
    box.replaceChildren(frame);
    box.classList.add('map-loaded');
  }));

  /* Reveal on scroll, staggered inside each section */
  const items = $$('[data-reveal]');
  if (!('IntersectionObserver' in window) || reduceMotion) {
    items.forEach((el) => el.classList.add('in'));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const group = $$('[data-reveal]:not(.in)', el.closest('section, aside, header') || document);
      el.style.transitionDelay = `${Math.max(0, group.indexOf(el)) * 80}ms`;
      el.classList.add('in');
      io.unobserve(el);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
  items.forEach((el) => io.observe(el));
})();
