<?php
/**
 * Block theme: every page is rendered from templates/*.html.
 * This file only exists because WordPress requires it.
 *
 * @package TerapieCorporala
 */
